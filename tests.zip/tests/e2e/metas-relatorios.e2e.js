const fs = require('fs');
const path = require('path');
const { By, until, url, criarDriver, criarUsuarioApi, loginPelaTela, esperarSwal, emailUnico } = require('./helpers/driver');

describe('Metas e relatórios do administrador (RF-003 / RF-006)', () => {
    let driver;
    const admin = { email: emailUnico('admin'), senha: 'Admin@123', role: 'admin' };

    beforeAll(async () => {
        driver = await criarDriver();
        await criarUsuarioApi({ nome: 'Camila', ...admin });
        await loginPelaTela(driver, admin.email, admin.senha);
        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);
    });
    afterAll(async () => { if (driver) await driver.quit(); });

    test('CT-E09 | meta mensal salva é persistida e reaparece preenchida ao reabrir a tela', async () => {
        await driver.get(url('/metas.html?role=admin'));
        const limite = await driver.findElement(By.id('inputLimiteM3'));
        await limite.clear();
        await limite.sendKeys('18');
        await driver.findElement(By.name('emailAlerta')).sendKeys('camila@oliboti.com.br');
        await driver.findElement(By.css('.btn-metas')).click();

        await driver.wait(until.urlContains('salvo=true'), 10000);
        await driver.wait(async () =>
            (await driver.findElement(By.id('inputLimiteM3')).getAttribute('value')) === '18', 10000,
            'O limite salvo (18) não voltou preenchido no formulário');
    });

    test('CT-E10 | "Baixar relatório PDF" gera e baixa o arquivo com o nome e o formato corretos', async () => {
        await driver.get(url('/relatorios.html?role=admin'));
        await driver.findElement(By.id('btnGerarPDF')).click();
        await esperarSwal(driver, 'PDF Gerado!');

        const arquivo = path.join(driver.pastaDownload, 'Farmaqua_mensal_2026-01_2026-06.pdf');
        await driver.wait(async () => fs.existsSync(arquivo) && fs.statSync(arquivo).size > 0, 10000,
            'O PDF não foi baixado');
        expect(fs.readFileSync(arquivo).subarray(0, 4).toString()).toBe('%PDF');
    });
});
