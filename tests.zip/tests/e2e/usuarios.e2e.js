const { By, until, url, criarDriver, criarUsuarioApi, loginPelaTela, irParaLogin, esperarSwal, emailUnico } = require('./helpers/driver');

describe('Cadastro de usuários e controle de acesso (RF-001 / RNF-007)', () => {
    let driver;
    const admin = { email: emailUnico('admin'), senha: 'Admin@123', role: 'admin' };
    const func = { email: emailUnico('func'), senha: 'Func@123', role: 'func' };

    beforeAll(async () => {
        driver = await criarDriver();
        await criarUsuarioApi({ nome: 'Camila', ...admin });
        await criarUsuarioApi({ nome: 'Auxiliar', ...func });
    });
    afterAll(async () => { if (driver) await driver.quit(); });

    async function preencherCadastro({ nome, email, role, senha, confirmar }) {
        await driver.findElement(By.name('nome')).sendKeys(nome);
        await driver.findElement(By.name('email')).sendKeys(email);
        await driver.findElement(By.css(`select[name="role"] option[value="${role}"]`)).click();
        await driver.findElement(By.id('senha')).sendKeys(senha);
        await driver.findElement(By.id('confirmarSenha')).sendKeys(confirmar);
        await driver.findElement(By.css('.btn-premium')).click();
    }

    test('CT-E04 | cadastro com senha e confirmação diferentes é bloqueado com "Senhas diferentes"', async () => {
        await loginPelaTela(driver, admin.email, admin.senha);
        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);
        await driver.get(url('/cadastrousuario.html?role=admin'));

        await preencherCadastro({ nome: 'Novo', email: emailUnico('novo'), role: 'func', senha: 'abc123', confirmar: 'xyz789' });

        await esperarSwal(driver, 'Senhas diferentes');
        expect(await driver.getCurrentUrl()).not.toContain('sucesso=true');
    });

    test('CT-E05 | cadastro válido exibe "Colaborador Autorizado!" e o novo usuário consegue entrar', async () => {
        const novo = { nome: 'Joana Auxiliar', email: emailUnico('joana'), role: 'func', senha: 'Joana@123' };
        await loginPelaTela(driver, admin.email, admin.senha);
        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);
        await driver.get(url('/cadastrousuario.html?role=admin'));

        await preencherCadastro({ ...novo, confirmar: novo.senha });
        await esperarSwal(driver, 'Colaborador Autorizado!');

        // O novo usuário faz login e cai no dashboard SEM os menus de administrador
        await loginPelaTela(driver, novo.email, novo.senha);
        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);
        expect(await driver.getCurrentUrl()).toContain('role=func');
        expect(await driver.findElement(By.id('lnkCadastro')).isDisplayed()).toBe(false);
    });

    test('CT-E06 | funcionário que abre a tela de cadastro é redirecionado ao dashboard (acesso negado)', async () => {
        await loginPelaTela(driver, func.email, func.senha);
        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);

        await driver.get(url('/cadastrousuario.html?role=func'));

        await driver.wait(until.urlContains('negado=true'), 10000);
        expect(await driver.getCurrentUrl()).toContain('dashboarddeconsumo.html');
    });
});
