module.exports = async () => {
    if (globalThis.__FARMAQUA_SERVER__) globalThis.__FARMAQUA_SERVER__.kill();
};
