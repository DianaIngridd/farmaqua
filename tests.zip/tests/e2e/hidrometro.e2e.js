const { By, until, url, criarDriver, criarUsuarioApi, loginPelaTela, esperarSwal, preencherData, emailUnico } = require('./helpers/driver');

describe('Lançamento do hidrômetro (RF-002 / RF-007 / RF-009)', () => {
    let driver;
    const func = { email: emailUnico('func'), senha: 'Func@123', role: 'func' };

    beforeAll(async () => {
        driver = await criarDriver();
        await criarUsuarioApi({ nome: 'Auxiliar', ...func });
        await loginPelaTela(driver, func.email, func.senha);
        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);
    });
    afterAll(async () => { if (driver) await driver.quit(); });

    async function lancar(data, valor) {
        await driver.get(url('/hidrometro.html?role=func'));
        await preencherData(driver, '#inputData', data);
        await driver.findElement(By.id('inputValor')).sendKeys(String(valor));
        await driver.findElement(By.css('.btn-confirmar')).click();
        await esperarSwal(driver, 'Lançamento Concluído!');
    }

    test('CT-E07 | dois lançamentos válidos: aparecem em "Leituras Recentes" e o consumo é calculado em litros', async () => {
        await lancar('2026-05-10', '100.000');
        await lancar('2026-05-11', '100.350');

        await driver.get(url('/hidrometro.html?role=func'));
        const corpo = await driver.findElement(By.id('corpoTabela'));
        await driver.wait(async () => (await corpo.getText()).includes('100.350'), 10000);
        expect(await corpo.getText()).toContain('100.000');

        const leituras = await (await fetch(url('/api/leituras'))).json();
        const segunda = leituras.find(l => l.valorM3 === 100.35);
        expect(segunda.consumoLiters).toBe(350);
    });

    test('CT-E08 | o campo "Descreva a atividade" só aparece quando o tipo é "Outro"', async () => {
        await driver.get(url('/hidrometro.html?role=func'));
        const campo = await driver.findElement(By.id('campoOutro'));
        expect(await campo.isDisplayed()).toBe(false);

        await driver.findElement(By.css('#selectAtividade option[value="OUTRO"]')).click();
        expect(await campo.isDisplayed()).toBe(true);

        await driver.findElement(By.css('#selectAtividade option[value="LIMPEZA"]')).click();
        expect(await campo.isDisplayed()).toBe(false);
    });
});
