const { By, until, url, criarDriver, criarUsuarioApi, loginPelaTela, esperarSwal, emailUnico } = require('./helpers/driver');

describe('Login e sessão (RF-008)', () => {
    let driver;
    const admin = { email: emailUnico('admin'), senha: 'Admin@123', role: 'admin' };

    beforeAll(async () => {
        driver = await criarDriver();
        await criarUsuarioApi({ nome: 'Camila', ...admin });
    });
    afterAll(async () => { if (driver) await driver.quit(); });

    test('CT-E01 | login com credenciais válidas abre o dashboard com menus de administrador', async () => {
        await loginPelaTela(driver, admin.email, admin.senha);

        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);
        expect(await driver.getCurrentUrl()).toContain('role=admin');
        const menuCadastro = await driver.findElement(By.id('lnkCadastro'));
        expect(await menuCadastro.isDisplayed()).toBe(true);
    });

    test('CT-E02 | login com senha incorreta exibe "Acesso Negado" e permanece na tela de login', async () => {
        await loginPelaTela(driver, admin.email, 'senha-errada');

        const texto = await esperarSwal(driver, 'Acesso Negado');
        expect(texto).toContain('E-mail ou senha incorretos.');
        expect(await driver.getCurrentUrl()).toContain('error=true');
    });

    test('CT-E03 | "Sair" (na tela Lançar Hidrômetro) encerra a sessão limpando o perfil salvo no navegador', async () => {
        await loginPelaTela(driver, admin.email, admin.senha);
        await driver.wait(until.urlContains('dashboarddeconsumo.html'), 10000);

        await driver.get(url('/hidrometro.html?role=admin'));
        await driver.findElement(By.css('.logout-btn')).click();
        await driver.wait(until.urlContains('teladelogin.html'), 10000);

        const perfilSalvo = await driver.executeScript("return localStorage.getItem('userRole')");
        expect(perfilSalvo).toBeNull();
    });
});
