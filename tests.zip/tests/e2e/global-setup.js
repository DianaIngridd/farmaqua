/**
 * Antes da suíte E2E: sobe o servidor de teste (banco em memória) em outro processo.
 * Para testar um servidor que você mesmo iniciou (ex.: com MONGODB_URI de um banco de
 * teste), defina BASE_URL e nada será iniciado:   BASE_URL=http://localhost:3000 npm run test:e2e
 */
const { spawn } = require('child_process');
const path = require('path');

async function esperarServidor(url, tentativas = 60) {
    for (let i = 0; i < tentativas; i++) {
        try { await fetch(url); return; } catch { await new Promise(r => setTimeout(r, 250)); }
    }
    throw new Error(`Servidor de teste não respondeu em ${url}`);
}

module.exports = async () => {
    if (process.env.BASE_URL) return;

    const porta = process.env.TEST_PORT || '3100';
    const filho = spawn(process.execPath, [path.join(__dirname, '..', 'support', 'start-test-server.js')], {
        env: { ...process.env, PORT: porta },
        stdio: ['ignore', 'inherit', 'inherit']
    });
    globalThis.__FARMAQUA_SERVER__ = filho;
    process.env.BASE_URL = `http://localhost:${porta}`;
    await esperarServidor(process.env.BASE_URL);
};
