/**
 * Utilitários compartilhados pelos testes Selenium do Farmaqua.
 *
 * Variáveis de ambiente (todas opcionais):
 *   BASE_URL             endereço do sistema (definido pelo global-setup)
 *   HEADLESS=0           abre o Chrome visível (padrão: sem janela)
 *   CHROMEDRIVER_PATH    caminho do chromedriver (padrão: Selenium Manager baixa sozinho)
 *   CHROMEDRIVER_ARGS    argumentos extras do chromedriver, separados por vírgula
 */
const os = require('os');
const fs = require('fs');
const path = require('path');
const { Builder, By, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

const base = () => process.env.BASE_URL;
const url = (caminho) => `${base()}/${caminho.replace(/^\//, '')}`;

async function criarDriver() {
    const pastaDownload = fs.mkdtempSync(path.join(os.tmpdir(), 'farmaqua-dl-'));
    const opcoes = new chrome.Options()
        .addArguments('--window-size=1366,900', '--no-sandbox', '--disable-dev-shm-usage')
        .setPageLoadStrategy('eager')
        .setUserPreferences({
            'download.default_directory': pastaDownload,
            'download.prompt_for_download': false
        });
    if (process.env.HEADLESS !== '0') opcoes.addArguments('--headless=new');

    const builder = new Builder().forBrowser('chrome').setChromeOptions(opcoes);
    if (process.env.CHROMEDRIVER_PATH) {
        const servico = new chrome.ServiceBuilder(process.env.CHROMEDRIVER_PATH);
        if (process.env.CHROMEDRIVER_ARGS) servico.addArguments(...process.env.CHROMEDRIVER_ARGS.split(','));
        builder.setChromeService(servico);
    }
    const driver = await builder.build();
    await driver.manage().setTimeouts({ implicit: 0, pageLoad: 30000 });
    driver.pastaDownload = pastaDownload;
    return driver;
}

/** Cria (ou atualiza) um usuário direto pela rota do sistema, sem passar pela interface. */
async function criarUsuarioApi({ nome = 'Usuário Teste', email, senha = 'Senha@123', role = 'func' }) {
    const corpo = new URLSearchParams({ nome, email, senha, role });
    await fetch(url('/Usuarios/Cadastrar'), { method: 'POST', body: corpo, redirect: 'manual' });
}

/** Limpa a sessão do navegador (localStorage) e volta para a tela de login. */
async function irParaLogin(driver) {
    await driver.get(url('/teladelogin.html'));
    await driver.executeScript('localStorage.clear()');
    await driver.get(url('/teladelogin.html'));
}

/** Faz login pela tela, como o usuário faria. */
async function loginPelaTela(driver, email, senha) {
    await irParaLogin(driver);
    await driver.findElement(By.css('input[name="email"]')).sendKeys(email);
    await driver.findElement(By.css('input[name="password"]')).sendKeys(senha);
    await driver.findElement(By.css('.btn-main')).click();
}

/** Espera o SweetAlert2 aparecer e devolve seu texto completo. */
async function esperarSwal(driver, textoEsperado) {
    const popup = await driver.wait(until.elementLocated(By.css('.swal2-popup')), 10000);
    await driver.wait(until.elementIsVisible(popup), 5000);
    if (textoEsperado) {
        await driver.wait(async () => (await popup.getText()).includes(textoEsperado), 5000,
            `SweetAlert não exibiu "${textoEsperado}"`);
    }
    return popup.getText();
}

/** Define o valor de um <input type="date"> sem depender do idioma do Chrome. */
async function preencherData(driver, seletor, aaaaMmDd) {
    const el = await driver.findElement(By.css(seletor));
    await driver.executeScript(
        "arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input', {bubbles:true}));",
        el, aaaaMmDd);
}

const emailUnico = (prefixo) => `${prefixo}.${Date.now()}.${Math.floor(Math.random() * 1e4)}@oliboti.com.br`;

module.exports = { By, until, url, criarDriver, criarUsuarioApi, irParaLogin, loginPelaTela, esperarSwal, preencherData, emailUnico };
