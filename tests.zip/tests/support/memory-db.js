/**
 * Banco em memória para os testes automatizados do Farmaqua.
 *
 * Substitui os métodos de consulta dos models Mongoose (find, findOne, create, ...)
 * por versões que guardam os dados em arrays. Assim os testes de API e de interface
 * rodam sem MongoDB instalado e SEM tocar no banco real (Atlas).
 *
 * Mantém o que importa para os testes:
 *  - validação de schema do próprio Mongoose (required, enum, default) no create();
 *  - filtros usados pelo server.js ($lt, $lte, $gte, $ne e igualdade);
 *  - CastError para _id inválido, como no Mongoose real;
 *  - upsert sem validação no findOneAndUpdate (comportamento padrão do Mongoose).
 *
 * Para validar contra um MongoDB de verdade, NÃO use este arquivo: suba o servidor
 * com MONGODB_URI apontando para um banco de teste e rode os E2E com BASE_URL.
 */
const mongoose = require('mongoose');

function comparavel(v) {
    return v instanceof Date ? v.getTime() : v;
}

function bate(doc, filtro = {}) {
    return Object.entries(filtro).every(([campo, cond]) => {
        const valor = doc[campo];
        const ehOperador = cond && typeof cond === 'object' &&
            !(cond instanceof Date) && !(cond instanceof mongoose.Types.ObjectId);
        if (!ehOperador) return String(comparavel(valor)) === String(comparavel(cond));
        return Object.entries(cond).every(([op, ref]) => {
            const a = comparavel(valor), b = comparavel(ref);
            switch (op) {
                case '$lt': return a < b;
                case '$lte': return a <= b;
                case '$gt': return a > b;
                case '$gte': return a >= b;
                case '$ne': return String(a) !== String(b);
                default: throw new Error(`Operador não suportado no banco em memória: ${op}`);
            }
        });
    });
}

class Consulta {
    constructor(executar) { this._executar = executar; this._ordem = null; }
    sort(ordem) { this._ordem = ordem; return this; }
    then(ok, erro) { return Promise.resolve().then(() => this._executar(this._ordem)).then(ok, erro); }
}

function ordenar(lista, ordem) {
    if (!ordem) return lista;
    const [[campo, sentido]] = Object.entries(ordem);
    return [...lista].sort((x, y) => {
        const a = comparavel(x[campo]), b = comparavel(y[campo]);
        return (a < b ? -1 : a > b ? 1 : 0) * (sentido < 0 ? -1 : 1);
    });
}

function validarId(id, Model) {
    if (!mongoose.isValidObjectId(id)) {
        const erro = new Error(`Cast to ObjectId failed for value "${id}" (type string) at path "_id" for model "${Model.modelName}"`);
        erro.name = 'CastError';
        throw erro;
    }
}

function instalar(Model) {
    const dados = [];
    Model.__dados = dados;

    Model.find = (filtro) => new Consulta((ordem) => ordenar(dados.filter(d => bate(d, filtro)), ordem).map(d => ({ ...d })));
    Model.findOne = (filtro) => new Consulta((ordem) => {
        const achado = ordenar(dados.filter(d => bate(d, filtro)), ordem)[0];
        return achado ? { ...achado } : null;
    });
    Model.findById = (id) => new Consulta(() => {
        validarId(id, Model);
        const achado = dados.find(d => String(d._id) === String(id));
        return achado ? { ...achado } : null;
    });
    Model.create = async (valores) => {
        const doc = new Model(valores);
        await doc.validate();
        const salvo = { ...doc.toObject(), createdAt: new Date(), updatedAt: new Date() };
        dados.push(salvo);
        return { ...salvo };
    };
    Model.findByIdAndUpdate = (id, atualizacao) => new Consulta(() => {
        validarId(id, Model);
        const alvo = dados.find(d => String(d._id) === String(id));
        if (!alvo) return null;
        Object.assign(alvo, atualizacao, { updatedAt: new Date() });
        return { ...alvo };
    });
    Model.findByIdAndDelete = (id) => new Consulta(() => {
        validarId(id, Model);
        const i = dados.findIndex(d => String(d._id) === String(id));
        return i < 0 ? null : { ...dados.splice(i, 1)[0] };
    });
    Model.findOneAndUpdate = (filtro, atualizacao, opcoes = {}) => new Consulta(() => {
        let alvo = dados.find(d => bate(d, filtro));
        if (!alvo && opcoes.upsert) {
            const base = new Model({ ...filtro, ...atualizacao }).toObject();
            alvo = { ...base, createdAt: new Date() };
            dados.push(alvo);
        } else if (alvo) {
            Object.assign(alvo, atualizacao);
        }
        if (alvo) alvo.updatedAt = new Date();
        return alvo ? { ...alvo } : null;
    });
}

const MODELOS = ['Usuario', 'Meta', 'Leitura', 'Fatura'];

function instalarBancoEmMemoria() {
    MODELOS.forEach(nome => instalar(require(`../../models/${nome}`)));
}

function limparBancoEmMemoria() {
    MODELOS.forEach(nome => { require(`../../models/${nome}`).__dados.length = 0; });
}

module.exports = { instalarBancoEmMemoria, limparBancoEmMemoria };
