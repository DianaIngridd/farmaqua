/**
 * Sobe o Farmaqua para os testes E2E (Selenium) usando o banco em memória.
 *   node tests/support/start-test-server.js            (porta 3100 por padrão)
 *
 * Variáveis:
 *   PORT         porta do servidor (padrão 3100)
 *   OFFLINE_CDN  "1" = serve SweetAlert2/Bootstrap/Chart.js de node_modules em vez
 *                dos CDNs (útil em CI sem internet). Com internet, deixe desligado.
 */
const fs = require('fs');
const path = require('path');
const express = require('express');
const { instalarBancoEmMemoria } = require('./memory-db');

instalarBancoEmMemoria();
const app = require('../../server');

const host = express();

if (process.env.OFFLINE_CDN === '1') {
    const nm = path.join(__dirname, '..', '..', 'node_modules');
    const front = path.join(__dirname, '..', '..', '..', 'front');
    const trocas = [
        ['https://cdn.jsdelivr.net/npm/sweetalert2@11', '/__vendor/sweetalert2.all.min.js'],
        ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', '/__vendor/bootstrap.min.css'],
        ['https://cdn.jsdelivr.net/npm/chart.js', '/__vendor/chart.umd.js']
    ];
    const vendor = {
        '/__vendor/sweetalert2.all.min.js': path.join(nm, 'sweetalert2/dist/sweetalert2.all.min.js'),
        '/__vendor/bootstrap.min.css': path.join(nm, 'bootstrap/dist/css/bootstrap.min.css'),
        '/__vendor/chart.umd.js': path.join(nm, 'chart.js/dist/chart.umd.js')
    };
    // Antes do app do projeto: entrega os arquivos locais e reescreve os links dos CDNs nas páginas.
    host.use((req, res, next) => {
        if (vendor[req.path]) return res.sendFile(vendor[req.path]);
        const arquivo = req.path === '/' ? 'teladelogin.html' : req.path.replace(/^\//, '');
        if (req.method !== 'GET' || !arquivo.endsWith('.html')) return next();
        const caminho = path.join(front, arquivo);
        if (!fs.existsSync(caminho)) return next();
        let html = fs.readFileSync(caminho, 'utf-8');
        trocas.forEach(([de, para]) => { html = html.split(de).join(para); });
        res.type('html').send(html);
    });
}

host.use(app);

const PORT = process.env.PORT || 3100;
host.listen(PORT, () => console.log(`Farmaqua (teste, banco em memória) em http://localhost:${PORT}`));
