/**
 * Testes unitários dos schemas Mongoose. Usam apenas validateSync(): nenhuma conexão
 * com banco é aberta.
 */
const Usuario = require('../../models/Usuario');
const Leitura = require('../../models/Leitura');
const Meta = require('../../models/Meta');
const Fatura = require('../../models/Fatura');

describe('Model Usuario (RF-001 / RF-008)', () => {
    test('CT-U05 | rejeita usuário sem nome, e-mail, senha e perfil', () => {
        const erro = new Usuario({}).validateSync();
        expect(Object.keys(erro.errors).sort()).toEqual(['email', 'nome', 'role', 'senha']);
    });

    test('CT-U06 | aceita apenas os perfis "admin" e "func"', () => {
        const base = { nome: 'Ana', email: 'ana@oliboti.com.br', senha: '123456' };
        expect(new Usuario({ ...base, role: 'admin' }).validateSync()).toBeUndefined();
        expect(new Usuario({ ...base, role: 'func' }).validateSync()).toBeUndefined();
        expect(new Usuario({ ...base, role: 'gerente' }).validateSync().errors.role).toBeDefined();
    });
});

describe('Model Leitura (RF-002 / RF-007)', () => {
    test('CT-U07 | aplica padrões (NORMAL, unidade Principal) e rejeita atividade inválida', () => {
        const ok = new Leitura({ dataLeitura: new Date(), valorM3: 10, consumoLiters: 0 });
        expect(ok.validateSync()).toBeUndefined();
        expect(ok.tipoAtividade).toBe('NORMAL');
        expect(ok.unidadeId).toBe('Principal');

        const ruim = new Leitura({ dataLeitura: new Date(), valorM3: 10, consumoLiters: 0, tipoAtividade: 'FESTA' });
        expect(ruim.validateSync().errors.tipoAtividade).toBeDefined();
    });
});

describe('Model Meta (RF-006)', () => {
    test('CT-U08 | exige mês, limite e e-mail; consumo acumulado começa em 0', () => {
        const erro = new Meta({}).validateSync();
        expect(Object.keys(erro.errors).sort()).toEqual(['emailAlerta', 'limiteM3', 'mesReferencia']);

        const ok = new Meta({ mesReferencia: '2026-06', limiteM3: 15, emailAlerta: 'camila@oliboti.com.br' });
        expect(ok.validateSync()).toBeUndefined();
        expect(ok.consumoRealAcumulado).toBe(0);
    });
});

describe('Model Fatura (RF-010)', () => {
    test('CT-U09 | exige valor e arquivo; status padrão "PAGO"; rejeita status fora da lista', () => {
        const erro = new Fatura({}).validateSync();
        expect(Object.keys(erro.errors).sort()).toEqual(['arquivoUrl', 'valorFatura']);

        const ok = new Fatura({ valorFatura: 320.9, arquivoUrl: 'fatura.pdf' });
        expect(ok.validateSync()).toBeUndefined();
        expect(ok.status).toBe('PAGO');

        const ruim = new Fatura({ valorFatura: 1, arquivoUrl: 'x.pdf', status: 'ATRASADO' });
        expect(ruim.validateSync().errors.status).toBeDefined();
    });
});
