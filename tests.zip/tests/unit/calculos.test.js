const { calcularConsumoLitros, parsePeriodo } = require('../../utils/calculos');

describe('Cálculo de consumo do hidrômetro (RF-002 / RF-009)', () => {
    test('CT-U01 | consumo = (leitura atual − anterior) × 1000, em litros', () => {
        expect(calcularConsumoLitros(12.35, { valorM3: 12.0 })).toBe(350);
    });

    test('CT-U02 | primeira leitura (sem anterior) resulta em 0 L', () => {
        expect(calcularConsumoLitros(10.0, null)).toBe(0);
    });

    test('CT-U03 | leitura atual menor ou igual à anterior resulta em 0 L (nunca negativo)', () => {
        expect(calcularConsumoLitros(4.0, { valorM3: 5.0 })).toBe(0);
        expect(calcularConsumoLitros(5.0, { valorM3: 5.0 })).toBe(0);
    });

    test('CT-U04 | não propaga ruído de ponto flutuante (2,005 − 1,000 = 1005 L exatos)', () => {
        expect(calcularConsumoLitros(2.005, { valorM3: 1.0 })).toBe(1005);
        expect(calcularConsumoLitros(10.3, { valorM3: 10.1 })).toBe(200);
    });
});

describe('Período do relatório PDF (RF-003 / RF-004)', () => {
    test('CT-U10 | o mês final inclui o ÚLTIMO dia inteiro, em meses de 28, 30 e 31 dias', () => {
        expect(parsePeriodo('2026-01', '2026-02').fim.toISOString()).toBe('2026-02-28T23:59:59.999Z');
        expect(parsePeriodo('2026-01', '2026-04').fim.toISOString()).toBe('2026-04-30T23:59:59.999Z');
        expect(parsePeriodo('2026-01', '2026-05').fim.toISOString()).toBe('2026-05-31T23:59:59.999Z');

        // Leitura lançada pela tela às 12:00Z do último dia do mês deve entrar no relatório
        const leituraDia31 = new Date('2026-05-31T12:00:00Z');
        expect(leituraDia31 <= parsePeriodo('2026-01', '2026-05').fim).toBe(true);

        // Sem datas informadas: 2000-01-01 até "agora"
        const agora = new Date('2026-11-15T12:00:00Z');
        const { inicio, fim } = parsePeriodo(undefined, undefined, agora);
        expect(inicio.toISOString()).toBe('2000-01-01T00:00:00.000Z');
        expect(fim).toBe(agora);
    });
});