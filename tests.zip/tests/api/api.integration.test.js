/**
 * Testes de integração da API (Express + Mongoose) com banco em memória.
 * Cada teste descreve o comportamento ESPERADO pelos requisitos; um teste que falha
 * aponta um defeito do sistema (ver "Relatório de defeitos" no plano de testes).
 */
const { instalarBancoEmMemoria, limparBancoEmMemoria } = require('../support/memory-db');
instalarBancoEmMemoria();

const request = require('supertest');
const app = require('../../server');
const Usuario = require('../../models/Usuario');
const Leitura = require('../../models/Leitura');

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

beforeEach(() => limparBancoEmMemoria());

describe('Autenticação (RF-008)', () => {
    beforeEach(() => Usuario.create({ nome: 'Camila', email: 'camila@oliboti.com.br', senha: 'Senha@123', role: 'admin' }));

    test('CT-API01 | login válido redireciona ao dashboard com o perfil do usuário', async () => {
        const res = await request(app).post('/Auth/Login').type('form')
            .send({ email: 'Camila@Oliboti.com.br ', password: 'Senha@123' });
        expect(res.status).toBe(302);
        expect(res.headers.location).toBe('/dashboarddeconsumo.html?role=admin');
    });

    test('CT-API02 | senha incorreta volta ao login com ?error=true', async () => {
        const res = await request(app).post('/Auth/Login').type('form')
            .send({ email: 'camila@oliboti.com.br', password: 'errada' });
        expect(res.status).toBe(302);
        expect(res.headers.location).toBe('/?error=true');
    });

    test('CT-API03 | endpoints de dados exigem autenticação (RNF-007)', async () => {
        const res = await request(app).get('/api/leituras');   // sem login nenhum
        expect([401, 403]).toContain(res.status);
    });

    test('CT-API04 | recuperação de senha: a rota chamada pela tela existe', async () => {
        const res = await request(app).post('/Account/ForgotPassword').type('form')
            .send({ email: 'camila@oliboti.com.br' });
        expect(res.status).not.toBe(404);
    });
});

describe('Lançamento de leituras (RF-002 / RF-005 / RF-009)', () => {
    const lancar = (data, valor, extra = {}) =>
        request(app).post('/Leitura/Salvar').type('form')
            .send({ dataLeitura: `${data}T12:00:00Z`, valorM3: String(valor), tipoAtividade: 'NORMAL', ...extra });

    test('CT-API05 | calcula o consumo em litros pela diferença para a leitura anterior', async () => {
        await lancar('2026-05-01', 100.0);
        const res = await lancar('2026-05-02', 100.35);
        expect(res.status).toBe(302);
        const [, segunda] = await Leitura.find().sort({ dataLeitura: 1 });
        expect(segunda.consumoLiters).toBe(350);
    });

    test('CT-API06 | a foto de evidência enviada pelo formulário (campo "fotoLeitura") é aceita', async () => {
        const res = await request(app).post('/Leitura/Salvar')
            .field('dataLeitura', '2026-05-01T12:00:00Z').field('valorM3', '100')
            .attach('fotoLeitura', PNG, 'hidrometro.png');   // nome do campo em hidrometro.html
        expect(res.status).toBe(302);
    });

    test('CT-API07 | editar com ID inválido responde erro do cliente (4xx), não 500', async () => {
        const res = await request(app).put('/api/leituras/nao-e-um-id').send({ novoValorM3: 10 });
        expect(res.status).toBeGreaterThanOrEqual(400);
        expect(res.status).toBeLessThan(500);
    });

    test('CT-API08 | excluir leitura inexistente responde 404', async () => {
        const res = await request(app).delete('/api/leituras/64b7f0c2a1b2c3d4e5f60718');
        expect(res.status).toBe(404);
    });
});

describe('Financeiro e relatórios (RF-003 / RF-010)', () => {
    test('CT-API09 | custo acumulado = consumo (m³) × tarifa R$ 8,50', async () => {
        // Hidrômetro foi de 100 m³ para 101 m³: consumo de 1 m³ => R$ 8,50
        await Leitura.create({ dataLeitura: new Date('2026-05-01T12:00:00Z'), valorM3: 100, consumoLiters: 0 });
        await Leitura.create({ dataLeitura: new Date('2026-05-02T12:00:00Z'), valorM3: 101, consumoLiters: 1000 });
        const res = await request(app).get('/api/Financeiro/Resumo');
        expect(res.status).toBe(200);
        expect(res.body.custoAcumulado).toBe('8.50');
    });

    test('CT-API10 | gera PDF para download com o nome do relatório', async () => {
        const res = await request(app).post('/Relatorios/Gerar').type('form')
            .send({ tipoRelatorio: 'mensal', formato: 'PDF', dataInicio: '2026-01', dataFim: '2026-06' })
            .buffer(true).parse((r, cb) => { const c = []; r.on('data', d => c.push(d)); r.on('end', () => cb(null, Buffer.concat(c))); });
        expect(res.status).toBe(200);
        expect(res.headers['content-type']).toMatch(/application\/pdf/);
        expect(res.headers['content-disposition']).toContain('Farmaqua_mensal_2026-01_2026-06.pdf');
        expect(res.body.subarray(0, 4).toString()).toBe('%PDF');
    });
});
