# Configuração do Banco de Dados NoSQL (MongoDB)

Este projeto utiliza o **MongoDB** como banco de dados não-relacional (NoSQL), gerenciado na camada de back-end através do **Mongoose (ODM)**. 

A arquitetura NoSQL foi escolhida pela flexibilidade no armazenamento dos históricos de medições hídricas e escalabilidade dos alertas da farmácia.

## Estrutura das Coleções (Models)

O mapeamento e a criação das coleções (equivalentes às tabelas) ocorrem de forma automatizada pelo Mongoose a partir dos schemas definidos em `src/back/models/`. As principais coleções estruturadas são:

* **usuario:** Armazena o nome, e-mail corporativo, nível de permissão e a senha criptografada (`senha_hash`) para o controle de sessão.
* **leitura:** Registra o histórico diário de consumo coletado dos hidrômetros, associando o valor do visor, data e o usuário responsável pelo lançamento.
* **meta:** Guarda as metas e tetos hídricos estipulados pela gerência para os meses de referência.
* **fatura:** Armazena os dados consolidados das contas mensais e os caminhos dos arquivos PDF para auditoria.

## Como Inicializar o Banco

Por se tratar de um banco NoSQL com Mongoose, **não é necessário executar nenhum script prévio de criação de tabelas**. 
1. Certifique-se de que a string de conexão do cluster (`mongodb+srv://...`) esteja devidamente configurada no arquivo `server.js` ou em variáveis de ambiente (`.env`).
2. Ao iniciar o servidor com o comando `node server.js`, o Mongoose estabelecerá a conexão de forma transparente e criará as coleções automaticamente assim que as primeiras operações de escrita forem executadas.
