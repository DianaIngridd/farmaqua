# Introdução

A água é um recurso natural essencial para a vida e para diversas atividades produtivas, sendo considerada um elemento fundamental para o desenvolvimento sustentável. No entanto, o crescimento populacional, o aumento da produção industrial e o consumo descontrolado têm contribuído para a intensificação do desperdício e para a escassez hídrica em várias regiões do mundo. Nesse contexto, torna-se cada vez mais importante a implementação de soluções tecnológicas que auxiliem no monitoramento e na gestão eficiente do consumo de água. 

Em ambientes empresariais, como farmácias de manipulação, o uso da água é frequente em processos de limpeza, higienização de equipamentos, manipulação de substâncias e manutenção do ambiente. Entretanto, muitas dessas empresas não possuem sistemas que permitam acompanhar de forma detalhada o consumo de água em suas atividades diárias, o que dificulta a identificação de desperdícios e o controle adequado desse recurso. 

Diante desse cenário, este projeto propõe o desenvolvimento de um Sistema de Controle de Consumo de Água voltado para uma farmácia de manipulação localizada em Betim – MG. A proposta consiste na criação de uma solução tecnológica que permita registrar, monitorar e analisar o consumo de água, contribuindo para uma gestão mais sustentável e consciente dos recursos hídricos. 

O cliente parceiro deste projeto é uma farmácia de manipulação que realiza a produção de medicamentos personalizados e utiliza água em diversas etapas de seus processos internos. A parceria permitirá compreender melhor as necessidades reais do negócio e desenvolver uma solução que atenda às demandas do ambiente organizacional. 


## Cliente 

O cliente parceiro deste projeto é uma farmácia de manipulação localizada no município de Betim – MG, especializada na produção de medicamentos personalizados conforme prescrição médica. A organização atua no segmento farmacêutico, atendendo clientes que necessitam de fórmulas específicas, não disponíveis em escala industrial, e realiza atividades que demandam rigoroso controle sanitário e de qualidade.

A farmácia enquadra-se como uma empresa de pequeno porte, com estrutura enxuta e equipe reduzida, composta por proprietária, farmacêutica responsável, auxiliares de manipulação e setor administrativo. Seu nicho de mercado envolve a manipulação de medicamentos, cosméticos e outros produtos personalizados, atendendo principalmente a população local e profissionais da área da saúde.


## Problema

A gestão eficiente dos recursos hídricos tem se tornado um desafio crescente para organizações que dependem intensivamente do uso de água em seus processos produtivos. No caso das farmácias de manipulação, a água é um insumo essencial, sendo utilizada em atividades como higienização de ambientes e equipamentos, preparo de soluções, esterilização e manutenção das condições sanitárias exigidas pelos órgãos reguladores.

O cliente parceiro deste projeto, uma farmácia de manipulação localizada em Betim – MG, enfrenta dificuldades no controle e monitoramento do consumo de água em suas operações diárias. Atualmente, não há um sistema estruturado que permita acompanhar de forma detalhada o uso desse recurso ao longo do tempo, sendo o controle realizado apenas por meio da leitura mensal da conta fornecida pela concessionária.

Essa ausência de monitoramento contínuo impede a identificação precisa de padrões de consumo, desperdícios, vazamentos ou usos excessivos em determinados períodos. Como consequência, a gestão da empresa não dispõe de informações suficientes para tomar decisões estratégicas voltadas à redução de custos e à adoção de práticas mais sustentáveis.

Além disso, o elevado consumo de água representa não apenas um impacto financeiro, mas também ambiental, especialmente diante do cenário global de escassez hídrica e da crescente necessidade de uso consciente dos recursos naturais. No contexto empresarial, a falta de controle pode resultar em gastos desnecessários, baixa eficiência operacional e dificuldades no planejamento financeiro.

Outro fator relevante é que os processos realizados na farmácia exigem rigoroso cumprimento de normas sanitárias, o que torna inviável a simples redução indiscriminada do consumo. Assim, a organização necessita de meios que permitam equilibrar a economia de água com a manutenção da qualidade e segurança dos serviços prestados.

Diante desse cenário, identifica-se como problema central a ausência de uma ferramenta que possibilite o registro, acompanhamento e análise sistemática do consumo de água, dificultando a identificação de desperdícios e a implementação de medidas de gestão eficiente dos recursos hídricos.

A aplicação proposta será utilizada no ambiente organizacional da farmácia, envolvendo diferentes perfis de usuários, como proprietária, farmacêutica responsável, funcionários operacionais e setor administrativo. O objetivo é apoiar a tomada de decisões baseada em dados reais, contribuindo para a sustentabilidade financeira e ambiental da empresa.

Portanto, o desenvolvimento da solução surge como resposta à necessidade de maior controle, transparência e eficiência na utilização da água, um recurso essencial para o funcionamento da organização e para a preservação do meio ambiente.


## Objetivos

**Objetivo Geral:**  
Desenvolver um sistema para monitoramento e controle do consumo de água em uma farmácia de manipulação, permitindo registrar, acompanhar e analisar o uso desse recurso com foco na sustentabilidade e na redução de desperdícios. 

**Objetivos Específicos:**  
- Identificar os principais pontos de consumo de água dentro da farmácia de manipulação. 
- Modelar um sistema que permita registrar e acompanhar o consumo de água em diferentes setores. 
- Desenvolver funcionalidades que possibilitem a geração de relatórios de consumo. 
- Auxiliar na identificação de possíveis desperdícios de água. 
- Contribuir para práticas mais sustentáveis dentro da organização. 
 

## Justificativa

A gestão eficiente da água é um dos principais desafios ambientais da atualidade. De acordo com a Organização das Nações Unidas (ONU), milhões de pessoas no mundo enfrentam problemas relacionados à escassez de água, o que torna essencial a adoção de práticas sustentáveis no uso desse recurso. 

No ambiente empresarial, o monitoramento do consumo de água pode contribuir significativamente para a redução de desperdícios, diminuição de custos operacionais e promoção da responsabilidade ambiental. No entanto, muitas pequenas empresas ainda não possuem ferramentas tecnológicas que auxiliem nesse controle. 

Nesse contexto, o desenvolvimento de um sistema de controle de consumo de água pode trazer benefícios tanto para a gestão da farmácia de manipulação quanto para o meio ambiente. Além de facilitar o acompanhamento do consumo, a solução permitirá identificar padrões de uso, possíveis desperdícios e oportunidades de melhoria na gestão dos recursos hídricos. 


## Público-alvo

O público-alvo da aplicação é composto pelos profissionais que atuam na farmácia de manipulação e que possuem alguma relação com o controle operacional ou administrativo do estabelecimento. 

Entre os principais perfis de usuários do sistema estão: 

- Proprietária da farmácia, responsável por acompanhar indicadores de consumo e tomar decisões relacionadas à gestão de recursos. 
- Funcionários administrativos, que poderão registrar informações relacionadas ao consumo e acompanhar relatórios gerados pelo sistema. 
- Funcionários operacionais, que atuam em processos de manipulação, limpeza e manutenção, podendo contribuir com o registro de dados relacionados ao uso da água. 
- Esses usuários possuem diferentes níveis de familiaridade com tecnologia, sendo importante que o sistema apresente uma interface simples, intuitiva e de fácil utilização. 

