
# Projeto de interface

A interface da Farmaqua foi projetada seguindo princípios de usabilidade e acessibilidade, levando em consideração os diferentes perfis de usuários mapeados nas personas do projeto. O protótipo interativo foi desenvolvido no Figma, contemplando os fluxos de navegação entre as telas e as principais funcionalidades do sistema, como registro de leituras, geração de relatórios e controle de acesso diferenciado por perfil. O design das interfaces busca equilibrar clareza visual e eficiência operacional, garantindo que os requisitos funcionais e não funcionais estabelecidos na especificação sejam atendidos de forma intuitiva.

## User Flow

O User Flow da Farmaqua foi elaborado para representar os caminhos de navegação e as possíveis ações disponíveis para cada perfil de acesso no sistema. Por meio dessa técnica, foi possível alinhar, junto aos membros da equipe, a lógica de navegação da plataforma às funcionalidades definidas nos requisitos funcionais e nas histórias de usuário, garantindo que os fluxos atendessem às necessidades e à rotina de cada perfil de usuário.

Abaixo está a representação visual do fluxo de navegação atual da plataforma:

![Projeto de interface](images/userflowtela1.png)
![Projeto de interface](images/userflowtela2.png)
![Projeto de interface](images/userflowtela3.png)


### Diagrama de fluxo

O diagrama de fluxo da Farmaqua ilustra o funcionamento das principais funcionalidades da plataforma, apresentando a sequência de ações, decisões e processos executados pelos usuários. Essa representação permite compreender como cada funcionalidade se relaciona com as demais, servindo como base para o desenvolvimento do wireframe interativo e da implementação do sistema.

![Diagrama de fluxo](images/diagramadefluxo.jpeg)


## Wireframes

Os wireframes da Farmaqua representam a estrutura inicial da interface da plataforma, apresentando a organização das telas, dos componentes visuais e das funcionalidades previstas para o sistema. Esses protótipos auxiliam na visualização da disposição dos elementos e do fluxo de interação entre as páginas, contribuindo para o desenvolvimento de uma interface intuitiva, consistente e alinhada aos requisitos do projeto.

![Wireframe](images/Wireframe.png)

## Protótipo interativo

O protótipo interativo da Farmaqua tem como base os caminhos de navegação definidos no fluxo de usuário, o comportamento das funcionalidades representado no diagrama de fluxo e a estrutura das interfaces proposta nos wireframes. A integração desses elementos resulta em uma simulação da plataforma, auxiliando na visualização da experiência de uso e na validação da navegação e das funcionalidades previstas para o sistema.

Essa representação pode ser explorada por meio do protótipo interativo disponibilizado no link a seguir, permitindo visualizar, de forma prática, a navegação entre as telas e o comportamento esperado das principais funcionalidades da plataforma.

**Link:** https://www.figma.com/proto/XRhch4ntJ26Od7biWcM0ou/Untitled?node-id=2-2&t=TT81cGV6bXM6httl-1&scaling=min-zoom&content-scaling=fixed&page-id=0%3A1&starting-point-node-id=2%3A2


## Jornada do usuário no sistema

A jornada do usuário descreve, em alto nível de detalhes, as etapas que diferentes perfis de usuários realizam para concluir uma tarefa específica na aplicação. Essa técnica ajuda a identificar pontos fortes e oportunidades de melhoria na experiência.

O mapeamento da jornada da nossa aplicação foi estruturado integrando as ações operacionais aos gatilhos comportamentais do modelo AIDA (Atenção/Conscientização, Interesse, Desejo e Ação), dividindo-se da seguinte forma:

### Matriz de Jornada (Modelo AIDA)

#### 1. Conscientização (Atenção)
* **Objetivo:** Despertar no usuário o conhecimento sobre a necessidade do produto e o controle do desperdício.
* **Ações do Usuário:** O gestor percebe inconsistências ou valores elevados nas contas físicas de água da empresa e busca uma forma de centralizar e monitorar os gastos de forma diária. O operador de campo identifica a dificuldade de rastrear vazamentos usando apenas anotações em papel.
* **Pontos de Contato:** Painel de indicadores inicial do sistema, reuniões de alinhamento operacional.
* **Emoções e Percepções:** Preocupação com o desperdício, sentimento de desorganização com o método manual e expectativa por uma solução tecnológica.

#### 2. Interesse
* **Objetivo:** Aumentar o interesse e engajamento com a facilidade de uso da plataforma.
* **Ações do Usuário:** O operador acessa a interface de lançamentos da aplicação e nota que o formulário digital possui campos simples para inserção dos dados do hidrômetro. O gestor navega pelos gráficos temporais e percebe a facilidade de ler os dados mastigados na tela.
* **Pontos de Contato:** Interface de *Dashboard*, menus de navegação rápida do sistema web.
* **Emoções e Percepções:** Curiosidade positiva, alívio ao ver painéis limpos e percepção de ganho de tempo na rotina de trabalho.

#### 3. Desejo
* **Objetivo:** Estimular a intenção contínua de uso por meio da entrega de valor (alertas e inteligência).
* **Ações do Usuário:** O sistema dispara um alerta visual de consumo excessivo em um setor específico. O gestor sente a necessidade imediata de extrair um relatório detalhado para investigar o problema e tomar providências com a equipe de manutenção.
* **Pontos de Contato:** Central de Alertas do sistema, aba de Filtros Avançados de Relatórios.
* **Emoções e Percepções:** Senso de urgência controlado, confiança na precisão dos dados exibidos e desejo de solucionar o problema usando os dados gerados.

#### 4. Ação
* **Objetivo:** Execução da ação esperada e consolidação da tarefa no sistema.
* **Ações do Usuário:** O operador insere com sucesso os novos dados de medição no formulário validado. Simultaneamente, o gestor aplica os filtros por período, gera o relatório analítico na tela e clica no botão de exportar para salvar o documento oficial em formato PDF.
* **Pontos de Contato:** Formulário de registro de consumo, botão de exportação de relatórios da interface.
* **Emoções e Percepções:** Satisfação pela tarefa concluída rapidamente, segurança na tomada de decisões hídricas e sensação de eficiência operacional.
![Mapa da Jornada do Usuário](images/JornadadoUsuario.png)
---

## Interface do sistema

As interfaces apresentadas a seguir refletem a versão final das telas da Farmaqua, desenvolvidas a partir dos requisitos, dos fluxos de navegação e dos processos de negócio definidos para o projeto. Cada tela é acompanhada de uma breve descrição de sua finalidade, contextualizando sua contribuição para a execução das funcionalidades da plataforma e sua relação com os processos de negócio previamente modelados.

### Tela principal do sistema

A tela principal do sistema consiste em um *Dashboard* gerencial e operacional centralizado. Essa interface oferece ao usuário uma visão macro do consumo de água do período, exibindo gráficos de consumo histórico, comparativos de metas de sustentabilidade, alertas em tempo real sobre anomalias ou possíveis vazamentos na rede de hidrômetros e cartões de atalhos rápidos para as principais ações do sistema (lançamento de medições e emissão de relatórios).

![](images/TelaDashboard.png)

### Telas dos processos BPMN

#### Processo 1

O Processo 1 refere-se à **Coleta e Registro de Consumo de Água**. A interface desenvolvida para este fluxo permite o lançamento manualizado das leituras coletadas em campo pelos operadores ou a validação de logs de telemetria enviados por hidrômetros inteligentes. A tela dispõe de campos parametrizados para inserção da identificação do ponto de consumo, a data/hora da medição e o valor em metros cúbicos ($m^3$). O sistema realiza validações em tempo real para impedir o cadastro de valores inconsistentes ou duplicados.

![](images/TelaHidrometro.png)

#### Processo 2

O Processo 2 refere-se à **Solicitação e Emissão de Relatórios Gerenciais**. Esta interface disponibiliza aos gestores filtros avançados de busca por período cronológico (diário, semanal, mensal ou anual), setor geográfico da empresa ou por ponto de medição específico. Após o processamento dos filtros, a tela renderiza tabelas analíticas organizadas e gráficos de linha temporais, oferecendo opções para exportar e baixar os dados consolidados em formatos como PDF e CSV.

![](images/TelaRelatório.png)

### Demais telas do sistema

* **Tela de Login / Autenticação:** Interface inicial e segura da aplicação. Permite que os funcionários e gestores façam o login por meio de e-mail institucional e senha corporativa. O sistema valida as credenciais no banco de dados e direciona o usuário para o painel de controle de acordo com seu nível de acesso permitido.
* **Tela de Configurações e Gerenciamento de Perfil:** Espaço destinado à edição de dados cadastrais do operador, alteração de senhas de acesso e ajuste de parâmetros globais do sistema, como limites para disparo de alertas de consumo excessivo.

![](images/TelaLogin.png)
![](images/TelaRecuperacaoLogin.png)
![](images/TelaConsumo.png)
![](images/Telafinanceiro.png)
