# Referências

- BOGO, Allyson Belli; HENNING, Elisa; KALBUSCH, Andreza. **Monitoramento do consumo de água: uma revisão narrativa**. *Paranoá*, Brasília, v. 16, n. 34, p. 1–24, 2023. Disponível em: <https://doi.org/10.18830/issn.1679-0944.n34.2023.18>.

- SOARES, Anna Elis Paz; PRADO, Amanda Rafaely Monte do; SILVA, Simone Rosa da. **O monitoramento como ferramenta da redução do consumo de água potável na Faculdade de Ciências da Administração de Pernambuco**. *Tecno-Lógica*, v. 23, n. 1, 2019. Disponível em: <https://doi.org/10.17058/tecnolog.v23i1.11693>.

- SILVA, Rodrigo Emanuel Rodrigues da; PAULA, Heber Martins de. **Sistema de telemetria aplicado à análise e gestão do consumo de água em moradia universitária em Goiás**. In: *Simpósio Nacional de Sistemas Prediais*, 2024. Disponível em: <https://doi.org/10.46421/sispred.v4.8155>.

- BARBOSA, Lucas Sampaio; COELHO LEITE, Brenda Chaves. **Detecção de anomalias de consumo de água através de automação predial**. In: *Simpósio Nacional de Sistemas Prediais*, 2021. Disponível em: <https://doi.org/10.46421/sispred.v2i.1097>.

- ORGANIZAÇÃO DAS NAÇÕES UNIDAS (ONU). **Objetivo de Desenvolvimento Sustentável 6: Água Potável e Saneamento**. Disponível em: <https://brasil.un.org/pt-br/sdgs/6>.

- GHISI, Enedir; CORDOVA, Maria Carolina. **Avaliação do potencial de conservação de água em edifícios comerciais**. *Ambiente Construído*, Porto Alegre, v. 14, n. 4, p. 7–22, 2014. Disponível em: <https://seer.ufrgs.br/index.php/ambienteconstruido/article/view/43512>.
  
- ATZORI, Luigi; IERA, Antonio; MORABITO, Giacomo. **The Internet of Things: A Survey**. *Computer Networks*, v. 54, n. 15, p. 2787–2805, 2010. Disponível em: <https://doi.org/10.1016/j.comnet.2010.05.010>.

- ORGANIZAÇÃO DAS NAÇÕES UNIDAS (ONU). **Objetivo de Desenvolvimento Sustentável 6: Água Potável e Saneamento**. Disponível em: <https://brasil.un.org/pt-br/sdgs/6>.

- AGÊNCIA NACIONAL DE ÁGUAS E SANEAMENTO BÁSICO (ANA). **Portal da ANA**. Disponível em: <https://www.gov.br/ana>.

