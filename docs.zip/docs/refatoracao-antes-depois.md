# Refatoração de 2 métodos – antes e depois

Arquivos: `src/back/server.js` e `src/back/utils/calculos.js`
Cada refatoração é coberta por testes unitários (CT-U01…U04 e CT-U10).

---

## Refatoração 1 – Cálculo de consumo duplicado (`POST /Leitura/Salvar` e `PUT /api/leituras/:id`)

**Problema (code smell):** o mesmo bloco de cálculo estava copiado nas duas rotas, e ainda gerava
ruído de ponto flutuante (2,005 − 1,000 resultava em `1004.9999999999999 L`).

### ANTES (copiado nas duas rotas)
```js
let consumoLitros = 0;
if (leituraAnterior) {
    let diferencaM3 = valorAtualM3 - leituraAnterior.valorM3;
    diferencaM3 = Math.round(diferencaM3 * 1000) / 1000;
    consumoLitros = diferencaM3 > 0 ? diferencaM3 * 1000 : 0;
}
```

### DEPOIS (`utils/calculos.js`, chamada nas duas rotas)
```js
function calcularConsumoLitros(valorAtualM3, leituraAnterior) {
    if (!leituraAnterior) return 0;
    const diferencaM3 = Math.round((valorAtualM3 - leituraAnterior.valorM3) * 1000) / 1000;
    return diferencaM3 > 0 ? Math.round(diferencaM3 * 1000) : 0;
}

// nas rotas:
const consumoLitros = calcularConsumoLitros(valorAtualM3, leituraAnterior);
```

**Ganhos:** regra em um único lugar (DRY), testável sem banco/Express e defeito de arredondamento corrigido
(`calcularConsumoLitros(2.005, {valorM3: 1})` → `1005`).

---

## Refatoração 2 – Montagem do período em `POST /Relatorios/Gerar`

**Problema (code smell + defeito):** a conversão do período estava embutida na rota de 140 linhas e usava
`dataFim + '-31'`. Isso (a) deixava de fora as leituras do último dia do mês (a tela grava `T12:00:00Z` e o
filtro terminava às `00:00Z`) e (b) em fevereiro estendia o relatório até 3 de março.

### ANTES
```js
const dataInicioDate = dataInicio ? new Date(dataInicio + '-01') : new Date('2000-01-01');
const dataFimDate = dataFim ? new Date(dataFim + '-31') : new Date();

const leituras = await Leitura.find({
    dataLeitura: { $gte: dataInicioDate, $lte: dataFimDate }
}).sort({ dataLeitura: 1 });
```

### DEPOIS
```js
// utils/calculos.js
function parsePeriodo(dataInicio, dataFim, agora = new Date()) {
    const inicio = dataInicio
        ? new Date(`${dataInicio}-01T00:00:00.000Z`)
        : new Date('2000-01-01T00:00:00.000Z');

    let fim = agora;
    if (dataFim) {
        const [ano, mes] = dataFim.split('-').map(Number);
        fim = new Date(Date.UTC(ano, mes, 0, 23, 59, 59, 999)); // último instante do mês
    }
    return { inicio, fim };
}

// na rota:
const { inicio, fim } = parsePeriodo(dataInicio, dataFim);
const leituras = await Leitura.find({
    dataLeitura: { $gte: inicio, $lte: fim }
}).sort({ dataLeitura: 1 });
```

**Ganhos:** função pequena e testável, fim do período correto em meses de 28, 30 e 31 dias
(`parsePeriodo('2026-01','2026-02').fim` → `2026-02-28T23:59:59.999Z`).
