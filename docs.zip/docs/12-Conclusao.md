# Conclusão

O desenvolvimento do **Farmaqua** permitiu criar uma solução voltada ao monitoramento e à gestão do consumo de água na farmácia de manipulação Oliboti, em Betim – MG. O projeto integrou conceitos de engenharia de software com práticas de sustentabilidade, oferecendo uma ferramenta capaz de centralizar informações, facilitar o acompanhamento do consumo hídrico e auxiliar na tomada de decisões.

## Principais Resultados

Durante o desenvolvimento do projeto, foram alcançados os seguintes resultados:

- Implementação de um back-end em **Node.js** integrado ao **MongoDB Atlas**, garantindo armazenamento seguro e persistente dos dados.
- Desenvolvimento de uma interface web dinâmica para cadastro de usuários, registro de informações e autenticação.
- Disponibilização de gráficos e relatórios que permitem acompanhar o consumo de água e identificar possíveis desperdícios.
- Organização das informações em um único sistema, proporcionando maior controle e facilidade de gerenciamento.

## Limitações

Apesar dos objetivos terem sido alcançados, a solução ainda apresenta algumas limitações:

- O registro do consumo de água depende da inserção manual das informações, podendo ocorrer erros de digitação ou atrasos na atualização dos dados.
- O sistema ainda não possui integração com dispositivos de medição automática.

## Trabalhos Futuros

Como possibilidades de evolução do projeto, destacam-se:

- Integração com sensores IoT para coleta automática do consumo de água em tempo real.
- Utilização de técnicas de Inteligência Artificial para prever padrões de consumo e detectar possíveis vazamentos.
- Expansão do sistema para monitorar outros indicadores ambientais, como consumo de energia elétrica e gerenciamento de resíduos, tornando o **Farmaqua** uma plataforma completa de sustentabilidade.
