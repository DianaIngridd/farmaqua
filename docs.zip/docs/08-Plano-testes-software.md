# Plano de testes de software

O plano de testes foi simplificado para focar nas funcionalidades vitais da plataforma Farmaqua, garantindo a validação dos fluxos críticos de segurança e operação sem sobrecarga na execução dos testes e gravações de vídeo.

## Testes Selecionados

| **Caso de teste** | **CT-001 – Cadastrar perfil de colaborador** |
|:---:|:---:|
| Requisito associado | RF-001 - O sistema deve permitir o cadastro de usuários. |
| Objetivo do teste | Verificar se um usuário administrador consegue cadastrar um novo colaborador com persistência no banco de dados. |
| Passos | - Acessar o navegador.<br>- Informar o endereço `http://localhost:3000/cadastrousuario.html?role=admin`.<br>- Preencher os campos **Nome do Colaborador**, **E-mail de Trabalho**, selecionar o nível de permissão (**Administrador** ou **Funcionário**), informar a **Senha** e **Confirmar**.<br>- Clicar no botão **"SALVAR CREDENCIAIS"**. |
| Critério de êxito | - O sistema exibe a mensagem **"Colaborador Autorizado!"** por meio do SweetAlert2.<br>- O novo colaborador é cadastrado com sucesso.<br>- Os dados são persistidos no banco de dados **MongoDB Atlas**. |
| Responsável pela elaboração do caso de teste | Equipe de Desenvolvimento Farmaqua. |

<br>

| **Caso de teste** | **CT-002 – Efetuar Login e Encerramento de Sessão** |
|:---:|:---:|
| Requisito associado | RF-008 - O sistema deve permitir o login diferenciado e controle de acesso. |
| Objetivo do teste | Garantir que o usuário cadastrado consiga se autenticar e que a sessão seja encerrada com segurança ao sair do sistema. |
| Passos | - Acessar o navegador.<br>- Informar o endereço `http://localhost:3000/teladelogin.html`.<br>- Inserir o **E-mail** e a **Senha** cadastrados no teste anterior.<br>- Clicar no botão **"Acessar Portal"**.<br>- Após entrar no painel, clicar no botão **"Sair"** do menu lateral. |
| Critério de êxito | - O sistema valida as credenciais e permite o acesso ao painel correspondente ao perfil do usuário.<br>- Ao clicar em **"Sair"**, a sessão é encerrada, o `localStorage` é limpo e o usuário é redirecionado para a tela de login. |
| Responsável pela elaboração do caso de teste | Equipe de Desenvolvimento Farmaqua. |

<br>

| **Caso de teste** | **CT-003 – Lançamento de Hidrômetro com Cálculo de Consumo** |
|:---:|:---:|
| Requisito associado | RF-002 / RF-009 - Registro diário do hidrômetro e cálculo automático do consumo em litros. RF-007 - O sistema deve permitir registrar se houve alguma atividade fora do comum no dia para justificar variações no hidrômetro. |
| Objetivo do teste | Validar se o sistema registra a medição atual do hidrômetro e calcula automaticamente o consumo com base na leitura anterior. Verificar se o sistema permite anexar notas explicativas a um lançamento diário de consumo. |
| Passos | - Acessar o navegador.<br>- Informar o endereço `http://localhost:3000/hidrometro.html`.<br>- Inserir a **"Data da Leitura**", o **"Valor Atual no Visor**" (valor superior ao último registro) e no campo de **"Tipo de Atividade**", selecionar uma atividade de exceção (Ex: "Limpeza pesada do laboratório de manipulação")..<br>- Clicar no botão **"Confirmar Lançamento"**. |
| Critério de êxito | - O lançamento da medição é realizado com sucesso.<br>- O consumo de água é calculado automaticamente pela diferença entre a leitura atual e a anterior. O registro é armazenado contendo a string de texto da justificativa atrelada ao ID daquela medição específica e a justificativa fica visível ao consultar o histórico de auditoria.<br>- O painel (dashboard) é atualizado exibindo o consumo hídrico diário. |
| Responsável pela elaboração do caso de teste | Equipe de Desenvolvimento Farmaqua. |

<br>

| **Caso de teste** | **CT-004 – Definição de Meta de Consumo Hídrico** |
|:---:|:---:|
| Requisito associado | RF-006 - O sistema deve permitir que a gerência cadastre uma meta de consumo diário ou mensal para a farmácia. |
| Objetivo do teste | Validar se um usuário com perfil de administrador consegue cadastrar uma meta de consumo hídrico para acompanhamento no sistema. |
| Passos | - Realizar login com um usuário de perfil **Administrador**.<br>- Acessar a tela de definição de metas **"Metas da OliBoti**".<br>- Informar o valor da meta de consumo (em metros cúbicos).<br>- Clicar no botão **"Salvar Configurações"**. |
| Critério de êxito | - A meta de consumo é salva com sucesso no sistema.<br>- O valor fica disponível para consulta.<br>- O painel de consumo passa a exibir a meta cadastrada para comparação com o consumo registrado e se o consumo ultrapassar 90% da meta o sistema enviará um aviso automático para o email cadastrado. |
| Responsável pela elaboração do caso de teste | Equipe de Desenvolvimento Farmaqua. |

<br>

| **Caso de teste** | **CT-005 – Consultar Histórico e Emitir Relatório Gerencial** |
|:---:|:---:|
| Requisito associado | RF-003 - O sistema deve permitir visualizar relatórios de consumo de água. RF-004 - O sistema deve permitir consultar histórico de consumo. |
| Objetivo do teste | Validar se o sistema aplica corretamente os filtros cronológicos e processa a exportação do documento consolidado. |
| Passos | - Logar no sistema com uma conta autorizada e acessar a aba de Relatórios no menu lateral.<br>- Utilizar os campos de filtro para selecionar qual tipo relatório será gerado e uma "Data Inicial" e uma "Data Final" específicas.<br>- Clicar no botão "Baixar relatório PDF" para processar o download. |
| Critério de êxito | O sistema gera e inicia o download automático do arquivo oficial formatado contendo o resumo do período. |
| Responsável pela elaboração do caso de teste | Equipe de Desenvolvimento Farmaqua. |

<br>

## Ferramentas de testes (opcional)

Os testes da aplicação serão conduzidos de forma manual através do navegador web Google Chrome, utilizando o painel de Inspeção do Desenvolvedor (DevTools - Console/Network) para auditoria das rotinas da API Node.js e validação visual de sucesso.
 
