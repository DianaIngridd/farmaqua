# Plano de Testes de Usabilidade

O objetivo do plano de testes de usabilidade é obter informações sobre a facilidade de uso, a clareza das interfaces e a experiência dos usuários ao utilizar a plataforma **Farmaqua**. O foco dos testes é avaliar se a disposição dos elementos visuais e das funcionalidades permite uma navegação intuitiva, rápida e eficiente, auxiliando os colaboradores da Farmácia de Manipulação Oliboti no monitoramento e gerenciamento do consumo de água.

## Perfis e Critérios de Seleção dos Participantes

Os testes de usabilidade foram realizados **presencialmente na Farmácia de Manipulação Oliboti**, com a participação de **três colaboradores da empresa**, selecionados por representarem os perfis reais de utilização do sistema.

Os participantes foram classificados da seguinte forma:

- **Participante 1 (Perfil Gerência/Proprietária):** responsável pelo acompanhamento dos indicadores de consumo, definição de metas e tomada de decisões estratégicas.
- **Participante 2 (Perfil Técnico/Farmacêutico):** responsável pelo acompanhamento das informações operacionais e consulta aos relatórios de consumo.
- **Participante 3 (Perfil Operacional/Auxiliar):** responsável pelo lançamento diário das leituras do hidrômetro e demais operações rotineiras do sistema.

> **Conformidade com a LGPD:** Nenhum dado pessoal ou sensível dos participantes foi coletado ou divulgado. Os voluntários foram identificados apenas por perfis genéricos.

## Procedimentos e Método de Avaliação

Os testes foram conduzidos **presencialmente**, nas dependências da Farmácia de Manipulação Oliboti, utilizando o método de **observação direta** aliado à técnica **Think Aloud**, na qual os participantes verbalizaram suas impressões, dúvidas e dificuldades durante a execução das tarefas.

Cada colaborador realizou individualmente os cenários propostos utilizando a versão funcional do Farmaqua executada localmente (`http://localhost:3000`) e integrada ao banco de dados **MongoDB Atlas**.

Durante os testes, cada integrante da equipe observou a interação dos participantes, registrando o tempo de execução, a quantidade de erros, as dificuldades encontradas e o nível de satisfação dos usuários, sem interferir na realização das tarefas.

## Métricas Coletadas

Foram avaliados os seguintes indicadores durante cada cenário de teste:

| Métrica | Descrição |
|----------|-----------|
| **Taxa de sucesso** | Verifica se o participante concluiu a tarefa de forma independente. |
| **Tempo para conclusão** | Tempo necessário para finalizar a atividade, comparado ao tempo de referência de um integrante da equipe de desenvolvimento. |
| **Número de erros** | Quantidade de tentativas incorretas ou dificuldades encontradas durante a execução. |
| **Quantidade de cliques** | Número de interações necessárias para concluir cada tarefa. |
| **Satisfação do usuário** | Avaliada conforme a escala: **1 - Péssimo**, **2 - Ruim**, **3 - Regular**, **4 - Bom** e **5 - Ótimo**. |

## Cenários de Teste de Usabilidade

| Nº do cenário | Perfil Alvo | Descrição da Tarefa |
|---------------|-------------|---------------------|
| **1** | Auxiliar Operacional | Registrar uma nova leitura do hidrômetro da farmácia e verificar se o sistema calcula automaticamente o consumo diário de água. |
| **2** | Gerência / Proprietária | Acessar o dashboard do sistema, analisar os gráficos de consumo hídrico e identificar possíveis períodos de maior consumo para auxiliar na tomada de decisões. |
| **3** | Gerência / Administrador | Acessar a funcionalidade de gerenciamento de metas, cadastrar ou alterar uma meta de consumo hídrico e verificar sua atualização no painel gerencial. |
| **4** | Gerência / Administrador | Acessar a funcionalidade de cadastro de usuário e cadastrar um novo colaborador no sistema. |
| **5** | Todos os perfis | Realizar login no sistema, navegar pelas funcionalidades disponíveis conforme o perfil do usuário e, ao final, encerrar a sessão utilizando o botão **Sair**. |

## Recursos Demandados

- **Hardware:** computador da Farmácia Oliboti com acesso à internet.
- **Software:** navegador Google Chrome e aplicação Farmaqua executada localmente com integração ao MongoDB Atlas.
- **Ferramentas de apoio:** cronômetro para medição do tempo de execução e planilha para registro das observações realizadas durante os testes.

## Considerações Finais

Os testes realizados com os próprios colaboradores da Farmácia permitiram validar a usabilidade do sistema em um ambiente real de utilização. Os participantes conseguiram executar as tarefas propostas com elevado índice de sucesso, demonstrando facilidade de navegação, compreensão das funcionalidades e boa aceitação da interface.

As observações registradas durante os testes servirão como base para futuras melhorias na interface, contribuindo para tornar o **Farmaqua** ainda mais intuitivo, eficiente e alinhado às necessidades dos usuários finais.
