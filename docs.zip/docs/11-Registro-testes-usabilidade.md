# Registro de Testes de Usabilidade

Após a realização dos testes de usabilidade, foi elaborado este relatório com base nos cenários definidos no Plano de Testes de Usabilidade. Os testes foram executados **presencialmente na Farmácia de Manipulação Oliboti**, com a participação de **três colaboradores**, representando os perfis de Gerência, Farmacêutico e Auxiliar Operacional. Para garantir a conformidade com a **Lei Geral de Proteção de Dados (LGPD)**, os participantes foram identificados apenas como Usuário 1, Usuário 2 e Usuário 3.

## Cenário 1 – Registro de leitura do hidrômetro

| Usuário | Taxa de sucesso | Satisfação subjetiva | Tempo para conclusão |
|---------|-----------------|----------------------|----------------------|
| 1 | SIM | 5 | 22 segundos |
| 2 | SIM | 5 | 19 segundos |
| 3 | SIM | 4 | 25 segundos |
| **Média** | **100%** | **4,7** | **22 segundos** |
| **Tempo do especialista** | **SIM** | **5** | **12 segundos** |

**Comentários dos usuários:** O lançamento da leitura foi simples e intuitivo. Os participantes compreenderam facilmente o processo de registro do hidrômetro.

---

## Cenário 2 – Consulta ao dashboard de consumo

| Usuário | Taxa de sucesso | Satisfação subjetiva | Tempo para conclusão |
|---------|-----------------|----------------------|----------------------|
| 1 | SIM | 5 | 18 segundos |
| 2 | SIM | 4 | 24 segundos |
| 3 | SIM | 5 | 21 segundos |
| **Média** | **100%** | **4,7** | **21 segundos** |
| **Tempo do especialista** | **SIM** | **5** | **10 segundos** |

**Comentários dos usuários:** Os gráficos facilitaram a visualização das informações e auxiliaram na identificação do consumo de água da farmácia.

---

## Cenário 3 – Gerenciamento de metas de consumo

| Usuário | Taxa de sucesso | Satisfação subjetiva | Tempo para conclusão |
|---------|-----------------|----------------------|----------------------|
| 1 | SIM | 5 | 20 segundos |
| 2 | SIM | 4 | 27 segundos |
| 3 | SIM | 5 | 24 segundos |
| **Média** | **100%** | **4,7** | **24 segundos** |
| **Tempo do especialista** | **SIM** | **5** | **11 segundos** |

**Comentários dos usuários:** A funcionalidade foi considerada objetiva e de fácil utilização, permitindo configurar metas rapidamente.

---

## Cenário 4 – Cadastro de colaborador

| Usuário | Taxa de sucesso | Satisfação subjetiva | Tempo para conclusão |
|---------|-----------------|----------------------|----------------------|
| 1 | SIM | 5 | 34 segundos |
| 2 | SIM | 5 | 30 segundos |
| 3 | SIM | 4 | 37 segundos |
| **Média** | **100%** | **4,7** | **34 segundos** |
| **Tempo do especialista** | **SIM** | **5** | **18 segundos** |

**Comentários dos usuários:** O formulário apresentou boa organização e as mensagens de confirmação facilitaram a compreensão do processo de cadastro.

---

## Cenário 5 – Login e encerramento de sessão

| Usuário | Taxa de sucesso | Satisfação subjetiva | Tempo para conclusão |
|---------|-----------------|----------------------|----------------------|
| 1 | SIM | 5 | 14 segundos |
| 2 | SIM | 5 | 16 segundos |
| 3 | SIM | 5 | 15 segundos |
| **Média** | **100%** | **5,0** | **15 segundos** |
| **Tempo do especialista** | **SIM** | **5** | **8 segundos** |

**Comentários dos usuários:** O processo de autenticação foi considerado rápido e o encerramento da sessão ocorreu de forma clara e segura.

---

# Avaliação

Os testes de usabilidade demonstraram que o **Farmaqua** apresenta uma interface intuitiva e de fácil utilização para os colaboradores da Farmácia de Manipulação Oliboti. Todos os participantes conseguiram concluir os cenários propostos com **100% de taxa de sucesso**, evidenciando que as funcionalidades implementadas atendem aos requisitos definidos para o projeto.

A satisfação dos usuários permaneceu entre **4 (Bom)** e **5 (Ótimo)** em todos os cenários, indicando boa aceitação da aplicação. Os participantes destacaram positivamente a organização das telas, a clareza das informações, a rapidez das operações e as mensagens de confirmação exibidas pelo sistema.

Em relação ao tempo de execução, observou-se que os usuários levaram mais tempo do que o especialista para concluir as tarefas, resultado esperado devido ao maior conhecimento do desenvolvedor sobre a aplicação. Ainda assim, os tempos registrados foram considerados satisfatórios e não foram observadas dificuldades significativas durante a navegação.

Como oportunidades de melhoria, os participantes sugeriram ampliar as instruções de algumas telas, tornar determinados botões mais evidentes e incluir funcionalidades adicionais de acompanhamento do consumo hídrico. Essas observações serão consideradas nas próximas versões do Farmaqua, contribuindo para uma experiência de uso ainda mais intuitiva e eficiente.
