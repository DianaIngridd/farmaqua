# Modelagem dos processos de negócio

As modelagens de processos foram elaboradas para representar o fluxo das atividades relacionadas ao controle do consumo de água na Oliboti, considerando a situação atual e a proposta de melhoria. Por meio dos modelos AS-IS e TO-BE, foi possível analisar o processo existente, identificar ineficiências e retrabalhos, além de evidenciar como a solução Farmaqua pode otimizar essas atividades, tornando o controle mais ágil, organizado e eficiente.

## Modelagem da situação atual (Modelagem AS IS)

A modelagem AS IS tem como objetivo representar a forma atual de funcionamento dos processos de registro de consumo de água e geração de relatórios, evidenciando as atividades realizadas, bem como os principais pontos de ineficiência e possíveis falhas existentes no sistema.

No cenário atual, o processo de coleta de consumo é realizado de forma manual, em que o funcionário se desloca até o local, realiza a leitura do hidrômetro e anota os dados para posterior inserção no sistema. Esse método está sujeito a erros humanos, como anotações incorretas ou perda de informações, além de demandar mais tempo para a execução completa do processo, o que pode impactar na atualização dos dados e na confiabilidade das informações registradas.

Após a coleta, os dados são digitados manualmente no sistema, o que pode gerar retrabalho em casos de inconsistências ou falhas na inserção. A ausência de validações automatizadas torna o processo mais vulnerável a erros, comprometendo a qualidade das informações armazenadas.

No que diz respeito à geração de relatórios, o processo também apresenta limitações, uma vez que depende da busca manual de dados, organização das informações e montagem dos relatórios por parte do usuário ou funcionário responsável. Esse procedimento é mais demorado, sujeito a falhas e falta de padronização, além de depender diretamente da intervenção humana para sua execução.

Dessa forma, a modelagem AS IS evidencia um cenário com baixa automação, maior propensão a erros e menor eficiência operacional. A análise desses processos atuais é fundamental para identificar oportunidades de melhoria e servir como base para a proposta de otimização apresentada na modelagem TO BE.


## Descrição geral da proposta (Modelagem TO BE)

A proposta de modelagem TO BE tem como objetivo otimizar os processos de registro de consumo de água e geração de relatórios, por meio da automação e da redução de atividades manuais, que atualmente representam pontos de falha e ineficiência no sistema.

No cenário proposto, o processo de coleta de consumo passa a ser realizado de forma automatizada, utilizando dispositivos como hidrômetros inteligentes ou aplicações móveis, permitindo que os dados sejam capturados e enviados diretamente ao sistema em tempo real. Essa mudança elimina a necessidade de anotações manuais e reduz significativamente a ocorrência de erros humanos, além de garantir maior confiabilidade e agilidade no registro das informações.

Além disso, o sistema passa a incorporar mecanismos de validação automática dos dados coletados, identificando inconsistências e gerando alertas quando necessário. Isso possibilita uma atuação mais rápida por parte dos responsáveis, aumentando a qualidade das informações armazenadas.

No processo de geração de relatórios, a proposta TO BE prevê a automatização completa, permitindo que o usuário solicite relatórios diretamente no sistema, que serão gerados de forma instantânea a partir dos dados já armazenados. O sistema também oferece opções de visualização e exportação em diferentes formatos, como PDF e planilhas, facilitando a análise e a tomada de decisão.

Com essas melhorias, espera-se um aumento significativo na eficiência operacional, redução de erros, maior confiabilidade dos dados e melhor experiência para os usuários do sistema. A modelagem TO BE, portanto, representa uma evolução do processo atual, alinhando-o com práticas mais modernas e tecnológicas.


## Modelagem dos processos

![Modelagem dos processos](images/AS_IS_01.jpg)

![Modelagem dos processos](images/TO_BE_01.jpg)

![Modelagem dos processos](images/AS_IS_02.jpg)

![Modelagem dos processos](images/TO_BE_02.jpg)

## Indicadores de desempenho

Os principais indicadores de desempenho e algumas metas para o processo.

| **Indicador** | **Objetivos** | **Descrição** | **Fonte de dados** | **Fórmula de cálculo** |
| ---           | ---           | ---           | ---             | ---             |
| Taxa de leituras registradas automaticamente | Avaliar eficiência da automação | Mede a porcentagem de leituras feitas automaticamente em relação ao total | Tabela Consumo | (leituras automáticas / total de leituras) * 100 |
| Percentual de erros de leitura | Reduzir inconsistências nos dados | Mede a quantidade de leituras com erro ou inconsistência | Tabela Consumo | (leituras com erro / total de leituras) * 100 |
| Tempo médio de registro de consumo | Melhorar a eficiência do processo | Mede o tempo médio entre coleta e registro no sistema | Tabela Consumo | soma do tempo de registro / número de leituras |
| Taxa de relatórios gerados automaticamente | Avaliar nível de automação do sistema | Mede a porcentagem de relatórios gerados sem intervenção manual | Tabela Relatórios | (relatórios automáticos / total de relatórios) * 100 |
| Disponibilidade do sistema | Garantir funcionamento contínuo | Mede o tempo em que o sistema está disponível para uso | Logs de Sistema | ((tempo disponível / tempo total) * 100 |
