# Registro de testes de software

| **Caso de teste** 	| **CT-001 – Cadastrar perfil de colaborador** 	|
|:---:	|:---:	|
| Requisito associado | RF-001 - O sistema deve permitir o cadastro de usuários. |
 
 Responsável pelo registro da evidência: Natália Silva Oliveira.

 https://youtu.be/g5t_aSY8KkE

 ---

| **Caso de teste** 	| **CT-002 – Efetuar Login e Encerramento de Sessão** 	|
|:---:	|:---:	|
| Requisito associado | RF-008 - O sistema deve permitir o login diferenciado e controle de acesso. |

 Responsável pelo registro da evidência: Natália Silva Oliveira.

 https://youtu.be/WI9I_8z0UTE

 ---

 | **Caso de teste** 	| **CT-003 – Lançamento de Hidrômetro com Cálculo de Consumo** 	|
|:---:	|:---:	|
| Requisito associado | RF-002 / RF-009 - Registro diário do hidrômetro e cálculo automático do consumo em litros. RF-007 - O sistema deve permitir registrar se houve alguma atividade fora do comum no dia para justificar variações no hidrômetro. |

 Responsável pelo registro da evidência: Natália Silva Oliveira.

 https://youtu.be/vbUhi_QUaCA

 ---

  | **Caso de teste** 	| **CT-004 – Definição de Meta de Consumo Hídrico** 	|
|:---:	|:---:	|
| Requisito associado | RF-006 - O sistema deve permitir que a gerência cadastre uma meta de consumo diário ou mensal para a farmácia. |

 Responsável pelo registro da evidência: Natália Silva Oliveira.

 https://youtu.be/pxndChFcRIc

 ---

  | **Caso de teste** 	| **CT-005 – Consultar Histórico e Emitir Relatório Gerencial** 	|
|:---:	|:---:	|
| Requisito associado | RF-003 - O sistema deve permitir visualizar relatórios de consumo de água. RF-004 - O sistema deve permitir consultar histórico de consumo. |

 Responsável pelo registro da evidência: Natália Silva Oliveira.

 https://youtu.be/Pp4-tijY-cA

 ---
 
## Avaliação

A execução dos casos de teste demonstrou que as principais funcionalidades do **Farmaqua** atenderam aos requisitos definidos para o projeto. Os testes de cadastro de colaboradores, autenticação de usuários, lançamento de medições do hidrômetro e definição de metas foram concluídos com sucesso, comprovando o correto funcionamento da integração entre o front-end, o back-end em Node.js e o banco de dados MongoDB Atlas.

Entre os pontos fortes identificados, destacam-se a persistência dos dados em nuvem, a validação das informações antes do envio ao servidor, a autenticação de usuários com diferentes níveis de acesso e a atualização automática das informações apresentadas no painel de monitoramento. Além disso, a interface mostrou-se intuitiva, facilitando a utilização do sistema pelos usuários.

Como ponto de melhoria, verificou-se que o registro do consumo de água ainda depende da inserção manual das leituras do hidrômetro, o que pode ocasionar erros de digitação ou atrasos na atualização das informações. Também foram identificadas oportunidades para ampliar as funcionalidades do sistema, como a implementação de notificações automáticas quando o consumo ultrapassar determinados limites e integração com sensores IoT para coleta automática dos dados.

Nas próximas iterações, o grupo pretende aperfeiçoar a usabilidade da aplicação, ampliar os mecanismos de validação e segurança, implementar novos recursos de monitoramento e desenvolver funcionalidades que permitam maior automação na coleta e análise dos dados, tornando o sistema ainda mais eficiente no apoio à gestão sustentável dos recursos hídricos.
