# Arquitetura da solução

A arquitetura da Farmaqua descreve a estrutura do sistema a partir de seus principais componentes e do ambiente de hospedagem da aplicação. São contemplados elementos como front-end, back-end, banco de dados e serviços externos, além da forma como esses componentes se organizam e estabelecem comunicação entre si. 


## Diagrama de classes

O diagrama de classes representa a estrutura lógica da aplicação, descrevendo as principais entidades do sistema, seus atributos, operações e os relacionamentos estabelecidos entre elas. Essa representação auxilia na compreensão da organização dos componentes responsáveis pelas regras de negócio e pela persistência dos dados, servindo como referência para a implementação da aplicação e para a manutenção de sua estrutura.


![Diagrama de Classes](images/Classe_UML.png)

---

## Modelo de dados

O modelo de dados da Farmaqua define a estrutura das informações utilizadas pela aplicação, organizando os elementos necessários para atender às funcionalidades do sistema de monitoramento hídrico. Por se tratar de uma solução baseada em **MongoDB (NoSQL)**, a modelagem foca na flexibilidade e na agregação de documentos, utilizando o **Mongoose** como mapeador lógico (ODM).

### Modelo conceitual (Lógico-NoSQL)

Diferente dos bancos relacionais tradicionais, o modelo do Farmaqua foi estruturado pensando em documentos JSON flexíveis. As entidades principais mapeadas na aplicação e seus respectivos papéis são:

- **usuario:** Gerencia os dados de acesso, e-mail corporativo e níveis de permissão dos colaboradores.
- **leitura:** Registros diários dos consumos hídricos obtidos nos visores.
- **meta:** Parâmetros e limites mensais de consumo estipulados pela gerência para auditoria.
- **fatura:** Controle financeiro das contas da COPASA e caminhos dos anexos em PDF.

![Modelo conceitual](images/banco_de_dados_conceitual.jpg)


### Modelo físico (Documentos JSON/BSON)

Abaixo está a representação física de como os dados são estruturados e salvos dentro do MongoDB Atlas em formato de documentos (JSON). As referências entre coleções (como o vínculo de uma leitura a um usuário) são controladas via `ObjectId` pelo Mongoose na camada de Back-end.

#### Coleção: `usuario`

```json
{
  "_id": { "$oid": "6473abc1234567890123456a" },
  "nome_completo": "Natália Oliveira",
  "email_trabalho": "natalia@farmaqua.com.br",
  "senha_hash": "$2b$10$X7r...",
  "nivel_permissao": "administrador"
}
```

#### Coleção: `leitura`

```json
{
  "_id": { "$oid": "6473abc1234567890123456c" },
  "id_usuario": { "$oid": "6473abc1234567890123456a" },
  "data_leitura": "2026-06-28",
  "valor_visor": 1420,
  "foto_visor_path": "/uploads/img/foto-168798.png",
  "tipo_activity": "manual"
}
```

#### Coleção: `meta`

```json
{
  "_id": { "$oid": "6473abc1234567890123456d" },
  "mes_referencia": "Junho/2026",
  "limite_consumo": 1500.0
}
```

#### Coleção: `fatura`

```json
{
  "_id": { "$oid": "6473abc1234567890123456e" },
  "mes_referencia": "Maio/2026",
  "valor_conta_rs": 450.25,
  "pdf_fatura_path": "/storage/pdf/fatura-maio.pdf"
}
```

## Tecnologias

As tecnologias utilizadas no desenvolvimento da Farmaqua foram selecionadas com base na compatibilidade entre as camadas da aplicação, na facilidade de integração e na adequação ao escopo do projeto. A solução é estruturada em camadas de frontend, backend e banco de dados, que se comunicam por meio de requisições HTTP, permitindo que as ações realizadas pelo usuário na interface sejam processadas pelo servidor e persistidas na base de dados em nuvem.

Na camada de frontend, foram utilizados HTML5, CSS3 e JavaScript para a construção das interfaces, com o suporte da biblioteca SweetAlert2 para aprimorar a interação e o retorno visual ao usuário. O backend é implementado com Node.js e o framework Express, responsável pelo processamento das requisições e pela aplicação das regras de negócio do sistema.

Para o armazenamento e gerenciamento das informações, é empregado o MongoDB com hospedagem no Atlas, garantindo uma base de dados em nuvem com disponibilidade e escalabilidade adequadas ao projeto. Durante o desenvolvimento, a aplicação é executada em ambiente local na porta 3000, onde ocorre a comunicação entre o cliente e o servidor.


| **Dimensão**   | **Tecnologia**  |
| ---            | ---             |
| IDE            | Visual Studio Code  |
| Front-end      | HTML5 + CSS3 + JavaScript + SweetAlert2 |
| Back-end       | Node.js (Express)        |
| SGBD           | MongoDB + Atlas (Nuvem)           |
| Deploy         | Localhost (Porta 3000)          |


## Hospedagem

A arquitetura de hospedagem do projeto Farmaqua foi estruturada de forma híbrida para esta etapa de entrega, dividindo-se entre a execução da aplicação em ambiente local e o armazenamento de dados em nuvem:

__Banco de Dados (Nuvem):__ Os dados estão hospedados de forma permanente e definitiva no MongoDB Atlas. Por ser um serviço de banco de dados em nuvem (Database as a Service), ele garante a persistência a longo prazo, alta disponibilidade e segurança dos registros sem depender de uma máquina local ligada para armazenar as informações.

__Servidor Back-end e Front-end (Execução Local):__ A aplicação (API em Node.js e as páginas de interface) está configurada para funcionar via Localhost (porta 3000). O código-fonte foi componentizado de maneira independente, permitindo que qualquer avaliador clone o repositório, instale as dependências e execute o servidor localmente em sua própria máquina, mantendo a conexão direta com o banco na nuvem.

## Qualidade de software

Com base na norma ISO/IEC 25010, foram selecionadas algumas subcaracterísticas consideradas essenciais para o desenvolvimento do Sistema de Controle de Consumo de Água da farmácia de manipulação. Essas subcaracterísticas estão relacionadas às necessidades identificadas durante o levantamento dos requisitos e contribuem para garantir que o sistema atenda às expectativas dos usuários e da organização.

### 1. Adequação Funcional – Completude Funcional

A completude funcional refere-se à capacidade do sistema de fornecer todas as funções necessárias para atender aos objetivos definidos. No contexto deste projeto, é fundamental que o sistema permita registrar consumos de água, consultar históricos, gerar relatórios e auxiliar na identificação de desperdícios.

__Métrica:__ percentual de requisitos implementados em relação aos requisitos especificados.

__Meta:__ implementar 100% dos requisitos considerados essenciais para o funcionamento do sistema.

### 2. Eficiência de Desempenho – Comportamento Temporal

O comportamento temporal está relacionado ao tempo de resposta do sistema durante sua utilização. Como os usuários precisarão consultar dados e gerar relatórios com frequência, é importante que essas operações sejam executadas rapidamente, proporcionando uma experiência satisfatória e aumentando a produtividade.

__Métrica:__ tempo médio de resposta das consultas e relatórios.

__Meta:__ apresentar resultados em até 2 segundos para operações comuns.

### 3. Usabilidade – Operabilidade

A operabilidade representa a facilidade com que os usuários conseguem utilizar o sistema para realizar suas atividades. Considerando que os funcionários da farmácia possuem diferentes níveis de familiaridade com tecnologia, a interface deve ser intuitiva, simples e de fácil aprendizado.

__Métrica:__ percentual de usuários que conseguem executar as principais tarefas sem auxílio.

__Meta:__ pelo menos 90% dos usuários devem conseguir utilizar as funcionalidades básicas sem necessidade de treinamento avançado.

### 4. Confiabilidade – Disponibilidade

A disponibilidade mede a capacidade do sistema de permanecer acessível quando necessário. Como as informações de consumo precisam ser registradas e consultadas continuamente, é importante que o sistema apresente poucas interrupções durante sua operação.

__Métrica:__ percentual de tempo em que o sistema permanece disponível para uso.

__Meta:__ disponibilidade mínima de 99%.

### 5. Segurança – Confidencialidade

A confidencialidade garante que apenas usuários autorizados tenham acesso às informações armazenadas no sistema. Embora os dados não sejam altamente sensíveis, é importante proteger informações administrativas e impedir alterações indevidas nos registros de consumo.

__Métrica:__ percentual de funcionalidades protegidas por autenticação e número de acessos não autorizados identificados.

__Meta:__ 100% das funcionalidades administrativas protegidas por login e ausência de acessos indevidos.


As subcaracterísticas selecionadas foram Completude Funcional, Comportamento Temporal, Operabilidade, Disponibilidade e Confidencialidade. Elas foram escolhidas por estarem diretamente relacionadas aos objetivos do projeto e às necessidades da farmácia de manipulação. A definição de métricas permitirá avaliar a qualidade do sistema durante seu desenvolvimento e utilização, contribuindo para uma solução eficiente, confiável, segura e alinhada às expectativas dos usuários.
