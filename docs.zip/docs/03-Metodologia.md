
# Metodologia

A equipe adotou a metodologia ágil, utilizando o Scrum como framework de trabalho, organizando o desenvolvimento em sprints de curta duração iniciadas por uma reunião de planejamento para distribuição de tarefas. O acompanhamento das atividades é feito pelo GitHub Projects, configurado com as colunas Todo, In Progress e Done. A comunicação entre as cinco integrantes ocorre presencialmente e também via mensagens para alinhamentos e repasse de impedimentos. A prototipação das interfaces é realizada no Figma antes da implementação, e o desenvolvimento é feito no Visual Studio Code.

## Controle de versão

A ferramenta de controle de versão adotada no projeto foi o [Git](https://git-scm.com/), sendo que o [GitHub](https://github.com) foi utilizado para hospedagem do repositório.

O projeto segue a seguinte convenção para o nome de branches:

- `main`: versão estável já testada do software
- `unstable`: versão já testada do software, porém instável
- `testing`: versão em testes do software
- `dev`: versão de desenvolvimento do software

Quanto à gerência de issues, o projeto adota a seguinte convenção para etiquetas:

- `documentation`: melhorias ou acréscimos à documentação
- `bug`: uma funcionalidade encontra-se com problemas
- `enhancement`: uma funcionalidade precisa ser melhorada
- `feature`: uma nova funcionalidade precisa ser introduzida

A configuração do projeto no GitHub foi realizada com o objetivo de organizar o desenvolvimento e facilitar o trabalho colaborativo da equipe. Para isso, foi adotada uma estrutura baseada em branches, permitindo que diferentes versões do sistema fossem mantidas simultaneamente durante o ciclo de desenvolvimento.

A gestão das branches seguiu uma organização hierárquica, na qual a branch **dev** foi utilizada para o desenvolvimento de novas funcionalidades, a **testing** para validação e testes, a **unstable** para versões já integradas, porém ainda sujeitas a ajustes, e a **main** para armazenar a versão estável do sistema. Dessa forma, foi possível reduzir riscos e garantir maior controle sobre as alterações realizadas.

Os commits foram utilizados para registrar as modificações efetuadas ao longo do desenvolvimento, permitindo o acompanhamento do histórico do projeto e facilitando a identificação de mudanças específicas. Já os merges foram realizados para integrar as alterações entre as branches, promovendo a evolução gradual do sistema até sua incorporação à versão principal.

A gestão de tags foi empregada para marcar versões importantes do projeto, como entregas parciais e versões estáveis, facilitando a identificação de marcos relevantes no processo de desenvolvimento.

Quanto à gestão de issues, o GitHub foi utilizado para registrar, acompanhar e organizar as atividades da equipe. As demandas foram categorizadas por meio de etiquetas, permitindo distinguir tarefas relacionadas à documentação, correção de erros, melhorias e implementação de novas funcionalidades. Essa abordagem contribuiu para o controle das atividades e para o acompanhamento da evolução do projeto ao longo de seu desenvolvimento.

## Planejamento do projeto

###  Divisão de papéis

A distribuição das responsabilidades do projeto entre os integrantes grupo foi feita de acordo com as atividades de cada Sprint, buscando promover a colaboração e a participação de todos nas diferentes etapas do desenvolvimento.

A seguir, é apresentada a divisão de papéis adotada em cada Sprint.

#### Sprint 1
- _Scrum master_: Ana Julia
- Protótipos: Diana
- Testes: Carolina
- Documentação: Natália e Milena

#### Sprint 2
- _Scrum master_: Natália
- Desenvolvedor _front-end_: Diana e Milena
- Desenvolvedor _back-end_: Carolina
- Testes: Ana Julia

#### Sprint 3
- _Scrum master_: Milena
- Desenvolvedor _front-end_: Natália e Ana Julia
- Desenvolvedor _back-end_: Diana e Carolina
- Testes: Carol

#### Sprint 4
- _Scrum master_: Carolina
- Desenvolvedor _front-end_: Ana Julia
- Desenvolvedor _back-end_: Natália e Diana
- Testes: Milena

###  Quadro de tarefas

Os quadros abaixo apresentam a distribuição das tarefas entre os integrantes da equipe e o acompanhamento de sua execução ao longo do projeto, possibilitando a visualização das responsabilidades de cada membro e o monitoramento do progresso das atividades planejadas.

#### Sprint 1

Atualizado em: 21/04/2026

| Responsável   | Tarefa/Requisito | Iniciado em    | Prazo      | Status | Terminado em    |
| :----         |    :----         |      :----:    | :----:     | :----: | :----:          |
| Ana Júlia        | Ana atuou para eliminar qualquer obstáculo que atrapalhe o progresso da equipe, como problemas técnicos, falta de recursos ou conflitos. | 09/02/2026     | 15/03/2026 | ✔️    | 15/03/2026      |
| Carolina        | Carolina fez os diagramas de caso de uso.    | 14/03/2026     | 15/03/2026 | ✔️    |       15/03/2026          |
| Natália e Milena        | Fizemos a documentação como as histórias de usuário, os requisitos e o template  | 12/03/2026     | 15/03/2026 | ✔️     |      15/03/2026           |
| Diana        | Diana fez a criação do GitHub  |    13/05/2026        | 15/03/2026 | ✔️    |  15/03/2026     |

#### Sprint 2

Atualizado em: 21/04/2026

| Responsável   | Tarefa/Requisito | Iniciado em    | Prazo      | Status | Terminado em    |
| :----         |    :----         |      :----:    | :----:     | :----: | :----:          |
| Ana Júlia       | Ana Júlia desenvolveu a lógica dos processos para que pudessemos montar os diagramas as-is e to-be.   | 15/04/2026     | 15/03/2026 | ✔️    | 20/04/2026      |
| Carolina        | Carolina auxiliou no preenchimento dos templates da documentação.     | 15/04/2026     | 15/03/2026 | ✔️    | 20/04/2026      |
| Diana        | Desenvolveu os diagramas as-is e to-be e ajudou no preenchimento do github.  | 15/04/2026     | 15/03/2026 | ✔️    | 20/04/2026      |
| Natália e Milena        | Responsáveis pela documentação e pela visita técnica. | 15/04/2026     | 15/03/2026 | ✔️    | 20/04/2026      |

#### Sprint 3

Atualizado em: 17/05/2026

| Responsável   | Tarefa/Requisito | Iniciado em    | Prazo      | Status | Terminado em    |
| :----         |    :----         |      :----:    | :----:     | :----: | :----:          |
| Diana e Carolina     | Modelagem conceitual do Banco de Dados (DER na notação Peter Chen) e mapeamento para o modelo relacional lógico. | 25/04/2026     | 17/05/2026 | ✔️    | 17/05/2026      |
| Diana     | Elaboração das instruções SQL de nível físico (DDL/DML) e construção do Diagrama de Classes UML do sistema. | 25/04/2026     | 17/05/2026 | ✔️    | 17/05/2026      |
| Natália       | Criação do template padrão da aplicação (manual da marca), wireframes e desenvolvimento do protótipo interativo no Figma. | 25/04/2026     | 17/05/2026 | ✔️    | 17/05/2026      |
| Ana Júlia e Milena | Mapeamento da jornada do usuário, especificação do fluxo de navegação (user flow) e documentação das subcaracterísticas de qualidade ISO/IEC 25010. | 25/04/2026     | 17/05/2026 | ✔️    | 17/05/2026      |

#### Sprint 4

Atualizado em: 07/06/2026

| Responsável   | Tarefa/Requisito | Iniciado em    | Prazo      | Status | Terminado em    |
| :----         |    :----         |      :----:    | :----:     | :----: | :----:          |
| Diana e Natália     | Desenvolvimento do Back-end: implementação das rotas, lógica dos 3 CRUDs principais e métodos de abertura/fechamento de conexões com o BD. | 18/05/2026     | 05/06/2026 | ✔️    | 05/06/2026      |
| Carolina      | Integração do Banco de Dados: conexão do SGBD MySQL com o Back-end, organização física dos scripts e aplicação de boas práticas/refatoração nas classes. | 18/05/2026     | 05/06/2026 | ✔️    | 04/06/2026      |
| Natália       | Desenvolvimento do Front-end: finalização de telas em HTML/CSS/JS e integração de consumo das APIs para conexão da interface ao Back-end. | 19/05/2026     | 05/06/2026 | ✔️    | 05/06/2026      |
| Ana Julia e Milena | Organização da estrutura de recursos do repositório, preenchimento do relatório da Seção 5 (Uso do Software), referências e consolidação dos slides. | 20/05/2026     | 05/06/2026 | ✔️    | 05/06/2026      |

### Processo

A equipe adotou uma adaptação prática do framework ágil Scrum. O ciclo de desenvolvimento é balizado por Sprints de curta duração, iniciadas por uma reunião de planejamento (Sprint Planning) para distribuição de tarefas no início de cada ciclo. O acompanhamento e a execução das tarefas e o status de desenvolvimento da solução são monitorados através do recurso de gerenciamento de projeto oferecido pelo GitHub (GitHub Projects), configurado com colunas de fluxo de trabalho: Todo (A fazer), In Progress (Em execução) e Done (Concluído). As comunicações assíncronas diárias ocorrem por meio de canais internos de mensagens para repasse de impedimentos.

## Ferramentas

Os artefatos do projeto são desenvolvidos a partir de diversas plataformas e a relação dos ambientes com seu respectivo propósito é apresentada na tabela que se segue.

| Ambiente | Plataforma | Link de acesso |
| :--- | :--- | :--- |
| **Repositório de código fonte** | GitHub | [Acessar Repositório Git](https://github.com/ICEI-PUC-Minas-PBE-SI-TI/2026-1-p5-tias-grupo-4.git) |
| **Documentos do projeto** | GitHub Docs | [Acessar Documentação de Processos](https://github.com/ICEI-PUC-Minas-PBE-SI-TI/2026-1-p5-tias-grupo-4/tree/main/docs/processes) |
| **Projeto de interface** | Figma | [Acessar Protótipo Interativo](https://www.figma.com/proto/XRhch4ntJ26Od7biWcM0ou/Untitled?node-id=2-2&t=TT81cGV6bXM6httl-1&scaling=min-zoom&content-scaling=fixed&page-id=0%3A1&starting-point-node-id=2%3A2) |
| **Gerenciamento do projeto** | GitHub Projects | [Acessar Quadro de Tarefas (Kanban)](https://github.com/orgs/ICEI-PUC-Minas-PBE-SI-TI/projects/41) |
| **Hospedagem da Aplicação** | Vercel / Localhost | *Execução Local via porta 3000 (Ambiente de Testes)* |
