# Especificação do projeto

As especificações do projeto são constituídas por diferentes etapas que possuem o objetivo de garantir que o sistema seja seguro, estratégico e alinhado às necessidades reais da farmácia. Essas definições buscam reduzir riscos técnicos, assegurar a viabilidade prática da solução e garantir que a plataforma gere valor real em termos de economia e sustentabilidade, além de se adaptar facilmente à rotina da empresa.

## Modelo de negócio (*Business Model Canvas*)

O Modelo de Negócio foi elaborado com o objetivo de representar de forma visual os principais elementos envolvidos na proposta da Farmaqua. Sua construção foi baseada nas necessidades identificadas junto à farmácia de manipulação parceira, considerando os desafios relacionados ao monitoramento do consumo de água, à redução de desperdícios e à busca por práticas mais sustentáveis. O quadro do Canvas apresentado a seguir detalha como a plataforma entrega valor ao cliente, estruturando desde as parcerias estratégicas até os canais de relacionamento e o público-alvo do sistema.

![Quadro de modelo de negócios](images/ModeloDeNegocios.png "Exemplo de BMC.")


## Personas

A definição das personas do projeto Farmaqua foi feita a partir do mapeamento do público-alvo da Oliboti, considerando os diferentes papéis da equipe, desde a gestão até as atividades diárias. Com base nisso, foram criados perfis que representam os comportamentos, necessidades e desafios reais dos usuários, orientando o desenvolvimento do sistema para que fosse intuitivo, eficiente e útil na rotina da empresa.

![Personas](images/PersonaUm.png)
![Personas](images/PersonaDois.png)
![Personas](images/PersonaTres.png)


## Histórias de usuários

A partir da análise das personas do projeto, foram identificadas as histórias de usuário, que representam as necessidades e objetivos dos futuros usuários do sistema. São elas:

|EU COMO... `PERSONA`| QUERO/PRECISO ... `FUNCIONALIDADE` |PARA ... `MOTIVO/VALOR`                 |
|--------------------|------------------------------------|----------------------------------------|                
|EU COMO PROPRIETÁRIA| QUERO/PRECISO acessar um dashboard com o consumo mensal   |PARA tomar decisões sobre investimentos e redução de custos.  
|                    |                                       
|EU COMO FARMACÊUTICA| QUERO/PRECISO visualizar o consumo  de água                 |PARA garantir que as normas de higiene estão sendo seguidas com eficiência. 
|                    |                           |        
|  EU COMO AUXILIAR  | QUERO/PRECISO registrar a leitura  do hidrômetro de forma rápida.  |PARA que o sistema detecte anomalias no consumo imediatamente e evite desperdícios prolongados.    
|   |          |
|                    |                                    |              |



## Requisitos

As tabelas a seguir apresentam os requisitos funcionais e não funcionais que definem o escopo do projeto. Para estabelecer a ordem de implementação e a relevância de cada requisito, foi aplicada uma técnica de priorização, permitindo identificar quais funcionalidades são mais importantes para atender às necessidades da Oliboti.

### Requisitos funcionais

|ID    | Descrição do Requisito  | Prioridade |
|------|-----------------------------------------|----|
|RF-001| O sistema deve permitir o cadastro de usuários | ALTA | 
|RF-002| O sistema deve permitir o registo diário do índice do hidrômetro e calcular automaticamente o consumo em relação ao dia anterior. | ALTA |
|RF-003| O sistema deve permitir visualizar relatórios de consumo de água. | ALTA | 
|RF-004| O sistema deve permitir consultar histórico de consumo. | ALTA |
|RF-005| O sistema deve permitir editar ou atualizar registros de consumo. | ALTA |
|RF-006| O sistema deve permitir que a gerência cadastre uma meta de consumo diário total ou mensal para a farmácia.  | BAIXA |
|RF-007| O sistema deve permitir registrar se houve alguma atividade fora do comum no dia (Ex: "Limpeza pesada do laboratório" ou "Troca de filtro"), para justificar variações no hidrômetro único.  | ALTA |
|RF-008| O sistema deve permitir o login diferenciado para a gerência (vê tudo) e funcionários (apenas lançam dados). | ALTA |
|RF-009| O sistema deve calcular o gasto diário em litros fazendo a subtração da leitura anterior. | ALTA |
|RF-010| O sistema deve permitir anexar o valor da conta de água mensal para comparar o gasto medido pelo sistema com o valor cobrado. | ALTA |
|RF-011| O sistema deve exibir gráficos de linha mostrando a evolução do consumo ao longo dos dias.  | BAIXA |
|RF-012| O sistema deve destacar em vermelho os dias em que o consumo fugiu da média padrão da farmácia. | MÉDIA |



### Requisitos não funcionais

|ID     | Descrição do Requisito  |Prioridade |
|-------|-------------------------|----|
|RNF-001| O sistema deve possuir uma interface simples e fácil de utilizar. | ALTA | 
|RNF-002| O sistema deve garantir a segurança das informações registradas.  | ALTA |
|RNF-003| O sistema deve apresentar tempo de resposta rápido nas consultas. | ALTA |
|RNF-004| O sistema deve ser uma plataforma Web responsiva, garantindo compatibilidade com navegadores desktop. | MÉDIA |
|RNF-005| O  sistema deve garantir disponibilidade mínima de 99% durante o horário comercial. | ALTA |
|RNF-006| O sistema deve permitir backup periódico das informações registradas no banco de dados.  | BAIXA |
|RNF-007| O sistema deve garantir que apenas usuários autorizados tenham acesso às funcionalidades de administração do sistema. | ALTA |


## Restrições

As restrições do projeto Farmaqua correspondem aos fatores que influenciam e limitam o desenvolvimento da solução, considerando a realidade operacional da Oliboti. Essas restrições foram definidas para garantir que o sistema seja viável, compatível com os processos da farmácia e adequado aos recursos disponíveis, sem comprometer a eficiência das atividades diárias.

|ID| Restrição                                             |
|--|-------------------------------------------------------|
|001| O sistema deve ser acessível via web.  |
|002| Não haverá integração automática com hidrômetros nesta fase do projeto, sendo necessário o lançamento manual das leituras.        |
|003| O custo de manutenção do sistema deve ser baixo.  |
|004| O sistema será desenvolvido como projeto acadêmico durante o semestre letivo.   |


## Diagrama de casos de uso

Após o levantamento e a análise dos requisitos da Farmaqua, foi elaborado o diagrama de casos de uso com o objetivo de representar graficamente as funcionalidades do sistema e a interação dos usuários com a plataforma. O diagrama contempla os principais atores envolvidos na rotina da Oliboti, os casos de uso identificados e os relacionamentos existentes entre eles.

![Diagrama de casos de uso](images/caso_de_usuario.jpg)


