# Template padrão da aplicação

As diretrizes de layout padrão da Farmaqua definem a estrutura base utilizada em todas as páginas da aplicação, estabelecendo a identidade visual do sistema e garantindo consistência na experiência de uso. Nesta seção, são apresentadas as diretrizes do manual da marca, incluindo paleta de cores, tipografia, iconografia e o uso do logotipo, além da descrição da identidade visual e do seu significado dentro do contexto do projeto.

### Manual da Marca

O manual da marca estabelece as diretrizes visuais obrigatórias para manter a integridade da identidade da plataforma em qualquer estágio de desenvolvimento:

* **Paleta de Cores:** * *Azul Principal (`#1E3A8A`):* Representa a água, o foco hídrico e transmite seriedade, segurança e estabilidade técnica para a governança dos dados.
    * *Cinza Escuro / Slate (`#334155`):* Utilizado em textos, barras de navegação e componentes estruturais para garantir um contraste confortável à leitura e um visual moderno.
    * *Branco / Off-White (`#F8FAFC`):* Cor de fundo das páginas que limpa o excesso visual e destaca as informações numéricas importantes.
    * *Cores de Estado (Feedback):* Verde (`#10B981`) para confirmação de dados salvos com sucesso e Vermelho (`#EF4444`) para o disparo imediato de alertas de vazamentos ou consumos anômalos.
* **Tipografia:** A família de fontes adotada é a *Sans-serif* (com preferência para Inter ou Roboto). A ausência de serifas confere um aspecto limpo, técnico e altamente legível em telas digitais de baixa ou alta resolução, variando o peso (Bold para títulos e Regular para dados informativos).
* **Iconografia:** Os ícones utilizados pertencem a bibliotecas padronizadas e minimalistas (como *Font Awesome* ou *Heroicons*). Cada ícone possui uma semântica direta com a ação: um gráfico de linhas para a aba do *Dashboard*, uma gota com um sinal de mais ($+$) para o Registro de Consumo e uma folha ou impressora para a Emissão de Relatórios Sustentáveis.

### Identidade Visual e Significado do Logotipo

O logotipo da aplicação foi projetado seguindo linhas minimalistas e modernas, unindo dois conceitos centrais do ecossistema do projeto: **sustentabilidade ambiental** e **tecnologia da informação**. 

Sua composição gráfica funde o contorno geométrico de uma **gota d'água** (representando o recurso vital monitorado) com linhas internas estilizadas. Esse símbolo reflete diretamente o propósito e os valores da aplicação: trazer clareza, inteligência e inovação para conter o desperdício hídrico no cenário corporativo atual.

### Aplicação das Diretrizes (Tela de Exemplo)

Abaixo é apresentada a estrutura do layout padrão unificado, demonstrando a aplicação prática da paleta de cores, tipografia, posicionamento do logotipo e a barra lateral responsiva de navegação que rege todas as páginas do sistema:

![Exemplo de aplicação do template padrão do sistema](images/TelaDashboard.png)




